<template>
    <div>
        <SectionsDemo22Section1 />
        <SectionsDemo22Section2 />
        <SectionsDemo22Section3 />
        <SectionsDemo22Section4 />
        <SectionsDemo22Section5 />
        <SectionsDemo22Section6 />
        <SectionsDemo22Section7 />
        <SectionsDemo22Section8 />
        <SectionsDemo22Section9 />
        <SectionsDemo22Section10 />
        <SectionsDemo22Section11 />
        <SectionsDemo22Section12 />
        <SectionsDemo22Section13 />
        <SectionsDemo22Section14 />
        <SectionsDemo22Section15 />
        <SectionsDemo22Section16 />
        <SectionsDemo22Section17 />
        <SectionsDemo22Section18 />
        <SectionsDemo22Section19 />
        <SectionsDemo22Section20 />        
        <SectionsDemo22Section21 />        
    </div>
</template>

<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark scheme-blue"
        },
    })
</script>