<template>
    <div>
        <SectionsDemo8Section1 />
        <SectionsDemo8Section2 />
        <SectionsDemo8Section3 />
        <SectionsDemo8Section4 />
        <SectionsDemo8Section5 />
        <SectionsDemo8Section6 />
        <SectionsDemo8Section7 />
        <SectionsDemo8Section8 />
        <SectionsDemo8Section9 />
        <SectionsDemo8Section10 />
        <SectionsDemo8Section11 />
        <SectionsDemo8Section12 />
        <SectionsDemo8Section13 />
        <SectionsDemo8Section14 />
        <SectionsDemo8Section15 />
        <SectionsDemo8Section16 />
        <SectionsDemo8Section17 />
        <SectionsDemo8Section18 />
    </div>
</template>

<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-light scheme-blue"
        },
    })
</script>