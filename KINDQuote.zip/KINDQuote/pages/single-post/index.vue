<template>
    <div>
        <SectionsSinglePostSection1 />
        <SectionsSinglePostSection2 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2"
        },
    })
</script>