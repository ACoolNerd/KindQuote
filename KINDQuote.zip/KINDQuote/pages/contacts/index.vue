<template>
    <div>
        <SectionsContactsSection1 />
        <SectionsContactsSection2 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2"
        },
    })
</script>