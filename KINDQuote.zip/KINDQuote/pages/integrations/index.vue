<template>
    <div>
        <SectionsIntegrationsSection1 />
        <SectionsIntegrationsSection2 />
        <SectionsIntegrationsSection3 />
        <SectionsIntegrationsSection4 />
        <SectionsIntegrationsSection5 />
        <SectionsIntegrationsSection6 />
        <SectionsIntegrationsSection7 />
        <SectionsIntegrationsSection8 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2"
        },
    })
</script>