<template>
    <div>
        <SectionsDemo23Section1 />
        <SectionsDemo23Section2 />
        <SectionsDemo23Section3 />
        <SectionsDemo23Section4 />
        <SectionsDemo23Section5 />
        <SectionsDemo23Section6 />
        <SectionsDemo23Section7 />
        <SectionsDemo23Section8 />
        <SectionsDemo23Section9 />
        <SectionsDemo23Section10 />
        <SectionsDemo23Section11 />
        <SectionsDemo23Section12 />
        <SectionsDemo23Section13 />
        <SectionsDemo23Section14 />
        <SectionsDemo23Section15 />
        <SectionsDemo23Section16 />
        <SectionsDemo23Section17 />
        <SectionsDemo23Section18 />
        <SectionsDemo23Section19 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2 scheme-blue"
        },
    })
</script>