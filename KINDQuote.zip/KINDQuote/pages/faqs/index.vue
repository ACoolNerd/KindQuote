<template>
    <div>
        <SectionsFaqsSection1 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2"
        },
    })
</script>