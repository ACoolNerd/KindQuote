<template>
    <div>
        <SectionsDemo15Section1 />
        <SectionsDemo15Section2 />
        <SectionsDemo15Section3 />
        <SectionsDemo15Section4 />
        <SectionsDemo15Section5 />
        <SectionsDemo15Section6 />
        <SectionsDemo15Section7 />
        <SectionsDemo15Section8 />
        <SectionsDemo15Section9 />
        <SectionsDemo15Section10 />
        <SectionsDemo15Section11 />
        <SectionsDemo15Section12 />
        <SectionsDemo15Section13 />
        <SectionsDemo15Section14 />
        <SectionsDemo15Section15 />
        <SectionsDemo15Section16 />
        <SectionsDemo15Section17 />
        <SectionsDemo15Section18 />
        <SectionsDemo15Section19 />
        <SectionsDemo15Section20 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2 scheme-violet"
        },
    })
</script>