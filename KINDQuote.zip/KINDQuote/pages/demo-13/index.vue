<template>
    <div>
        <SectionsDemo13Section1 />
        <SectionsDemo13Section2 />
        <SectionsDemo13Section3 />
        <SectionsDemo13Section4 />
        <SectionsDemo13Section5 />
        <SectionsDemo13Section6 />
        <SectionsDemo13Section7 />
        <SectionsDemo13Section8 />
        <SectionsDemo13Section9 />
        <SectionsDemo13Section10 />
        <SectionsDemo13Section11 />
        <SectionsDemo13Section12 />
        <SectionsDemo13Section13 />
        <SectionsDemo13Section14 />
        <SectionsDemo13Section15 />
        <SectionsDemo13Section16 />
        <SectionsDemo13Section17 />
    </div>
</template>

<script setup>
useHead({
    bodyAttrs: {
        class: "navbar-dark scheme-pink"
    }
});
</script>
