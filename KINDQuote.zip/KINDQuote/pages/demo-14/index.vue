<template>
    <div>
        <SectionsDemo14Section1 />
        <SectionsDemo14Section2 />
        <SectionsDemo14Section3 />
        <SectionsDemo14Section4 />
        <SectionsDemo14Section5 />
        <SectionsDemo14Section6 />
        <SectionsDemo14Section7 />
        <SectionsDemo14Section8 />
        <SectionsDemo14Section9 />
        <SectionsDemo14Section10 />
        <SectionsDemo14Section11 />
        <SectionsDemo14Section12 />
        <SectionsDemo14Section13 />
        <SectionsDemo14Section14 />
        <SectionsDemo14Section15 />
        <SectionsDemo14Section16 />
        <SectionsDemo14Section17 />
        <SectionsDemo14Section18 />
        <SectionsDemo14Section19 />
    </div>
</template>

<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-light scheme-blue"
        },
    })
</script>