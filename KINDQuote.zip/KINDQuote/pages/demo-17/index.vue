<template>
    <div>
        <SectionsDemo17Section1 />
        <SectionsDemo17Section2 />
        <SectionsDemo17Section3 />
        <SectionsDemo17Section4 />
        <SectionsDemo17Section5 />
        <SectionsDemo17Section6 />
        <SectionsDemo17Section7 />
        <SectionsDemo17Section8 />
        <SectionsDemo17Section9 />
        <SectionsDemo17Section10 />
        <SectionsDemo17Section11 />
        <SectionsDemo17Section12 />
        <SectionsDemo17Section13 />
        <SectionsDemo17Section14 />
        <SectionsDemo17Section15 />
        <SectionsDemo17Section16 />
        <SectionsDemo17Section17 />
        <SectionsDemo17Section18 />
        <SectionsDemo17Section19 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2 scheme-magenta"
        },
    })
</script>