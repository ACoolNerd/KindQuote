<template>
    <div>
        <SectionsDemo5Section1 />
        <SectionsDemo5Section2 />
        <SectionsDemo5Section3 />
        <SectionsDemo5Section4 />
        <SectionsDemo5Section5 />
        <SectionsDemo5Section6 />
        <SectionsDemo5Section7 />
        <SectionsDemo5Section8 />
        <SectionsDemo5Section9 />
        <SectionsDemo5Section10 />
        <SectionsDemo5Section11 />
        <SectionsDemo5Section12 />
        <SectionsDemo5Section13 />
        <SectionsDemo5Section14 />
        <SectionsDemo5Section15 />
        <SectionsDemo5Section16 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2 scheme-blue"
        },
    })
</script>