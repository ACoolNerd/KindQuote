<template>
    <div>
        <SectionsProjectDetailsSection1 />
        <SectionsProjectDetailsSection2 />
    </div>
</template>

<script setup>
useHead({
    bodyAttrs: {
        class: "navbar-dark navbar-dark-2"
    }
});
</script>
