<template>
    <div>
        <SectionsCareersSection1 />
        <SectionsCareersSection2 />
        <SectionsCareersSection3 />
        <SectionsCareersSection4 />
        <SectionsCareersSection5 />
        <SectionsCareersSection6 />
        <SectionsCareersSection7 />
    </div>
</template>

<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-light"
        },
    })
</script>