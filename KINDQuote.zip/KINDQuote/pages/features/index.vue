<template>
    <div>
        <SectionsFeaturesSection1 />
        <SectionsFeaturesSection2 />
        <SectionsFeaturesSection3 />
        <SectionsFeaturesSection4 />
        <SectionsFeaturesSection5 />
        <SectionsFeaturesSection6 />
        <SectionsFeaturesSection7 />
        <SectionsFeaturesSection8 />
        <SectionsFeaturesSection9 />
        <SectionsFeaturesSection10 />
        <SectionsFeaturesSection11 />
        <SectionsFeaturesSection12 />
        <SectionsFeaturesSection13 />
        <SectionsFeaturesSection14 />
        <SectionsFeaturesSection15 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2"
        },
    })
</script>