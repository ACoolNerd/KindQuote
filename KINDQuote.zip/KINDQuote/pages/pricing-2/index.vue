<template>
    <div>
        <SectionsPricing2Section1 />
        <SectionsPricing2Section2 />
        <SectionsPricing2Section3 />
        <SectionsPricing2Section4 />
        <SectionsPricing2Section5 />
    </div>
</template>

<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2"
        },
    })
</script>