<template>
    <div>
        <SectionsDemo4Section1 />
        <SectionsDemo4Section2 />
        <SectionsDemo4Section3 />
        <SectionsDemo4Section4 />
        <SectionsDemo4Section5 />
        <SectionsDemo4Section6 />
        <SectionsDemo4Section7 />
        <SectionsDemo4Section8 />
        <SectionsDemo4Section9 />
        <SectionsDemo4Section10 />
        <SectionsDemo4Section11 />
        <SectionsDemo4Section12 />
        <SectionsDemo4Section13 />
        <SectionsDemo4Section14 />
        <SectionsDemo4Section15 />
        <SectionsDemo4Section16 />
        <SectionsDemo4Section17 />
        <SectionsDemo4Section18 />
        <SectionsDemo4Section19 />
        <SectionsDemo4Section20 />
    </div>
</template>

<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark"
        },
    })
</script>