<template>
    <div>
        <SectionsProjectsSection1 />
        <SectionsProjectsSection2 />
        <SectionsProjectsSection3 />
        <SectionsProjectsSection4 />
        <SectionsProjectsSection5 />
    </div>
</template>

<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2"
        },
    })
</script>