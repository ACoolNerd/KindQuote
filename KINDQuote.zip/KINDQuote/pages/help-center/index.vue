<template>
    <div>
        <SectionsHelpCenterSection1 />
        <SectionsHelpCenterSection2 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2"
        },
    })
</script>