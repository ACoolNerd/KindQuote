<template>
    <div>
        <SectionsDemo2Section1 />
        <SectionsDemo2Section2 />
        <SectionsDemo2Section3 />
        <SectionsDemo2Section4 />
        <SectionsDemo2Section5 />
        <SectionsDemo2Section6 />
        <SectionsDemo2Section7 />
        <SectionsDemo2Section8 />
        <SectionsDemo2Section9 />
        <!-- <SectionsDemo2Section10 /> -->
        <SectionsDemo2Section11 />
        <SectionsDemo2Section12 />
        <SectionsDemo2Section13 />
        <SectionsDemo2Section14 />
        <SectionsDemo2Section15 />
        <SectionsDemo2Section16 />
        <SectionsDemo2Section17 />
        <SectionsDemo2Section18 />
        <SectionsDemo2Section19 />
    </div>
</template>

<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark"
        },
    })
</script>
