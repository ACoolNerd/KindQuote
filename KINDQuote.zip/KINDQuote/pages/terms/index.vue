<template>
    <div>
        <SectionsTermsSection1 />
    </div>
</template>

<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark"
        },
    })
</script>