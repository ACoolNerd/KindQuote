<template>
    <div>
        <SectionsDemo11Section1 />
        <SectionsDemo11Section2 />
        <SectionsDemo11Section3 />
        <SectionsDemo11Section4 />
        <SectionsDemo11Section5 />
        <SectionsDemo11Section6 />
        <SectionsDemo11Section7 />
        <SectionsDemo11Section8 />
        <SectionsDemo11Section9 />
        <SectionsDemo11Section10 />
        <SectionsDemo11Section11 />
        <SectionsDemo11Section12 />
        <SectionsDemo11Section13 />
        <SectionsDemo11Section14 />
        <SectionsDemo11Section15 />
        <SectionsDemo11Section16 />
        <SectionsDemo11Section17 />
        <SectionsDemo11Section18 />
        <SectionsDemo11Section19 />
        <SectionsDemo11Section20 />
    </div>
</template>

<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark scheme-magenta"
        },
    })
</script>