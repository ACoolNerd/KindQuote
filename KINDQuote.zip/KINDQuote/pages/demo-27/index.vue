<template>
    <div>
        <SectionsDemo27Section1 />
        <SectionsDemo27Section2 />
        <SectionsDemo27Section3 />
        <SectionsDemo27Section4 />
        <SectionsDemo27Section5 />
        <SectionsDemo27Section6 />
        <SectionsDemo27Section7 />
        <SectionsDemo27Section8 />
        <SectionsDemo27Section9 />
        <SectionsDemo27Section10 />
        <SectionsDemo27Section11 />
        <SectionsDemo27Section12 />
        <SectionsDemo27Section13 />
        <SectionsDemo27Section14 />
        <SectionsDemo27Section15 />
        <SectionsDemo27Section16 />
        <SectionsDemo27Section17 />
        <SectionsDemo27Section18 />
        <SectionsDemo27Section19 />
        <SectionsDemo27Section20 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2 scheme-magenta"
        },
    })
</script>