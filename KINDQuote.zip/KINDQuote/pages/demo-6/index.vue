<template>
    <div>
        <SectionsDemo6Section1 />
        <SectionsDemo6Section2 />
        <SectionsDemo6Section3 />
        <SectionsDemo6Section4 />
        <SectionsDemo6Section5 />
        <SectionsDemo6Section6 />
        <SectionsDemo6Section7 />
        <SectionsDemo6Section8 />
        <SectionsDemo6Section9 />
        <SectionsDemo6Section10 />
        <SectionsDemo6Section11 />
        <SectionsDemo6Section12 />
        <SectionsDemo6Section13 />
        <SectionsDemo6Section14 />
        <SectionsDemo6Section15 />
        <SectionsDemo6Section16 />
        <SectionsDemo6Section17 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2 scheme-blue"
        },
    })
</script>