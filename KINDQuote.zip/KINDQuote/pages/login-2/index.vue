<template>
    <div>
        <SectionsLogin2Section1 />
    </div>
</template>

<script setup>
    definePageMeta({
        layout: "no-header-footer",
    })
</script>