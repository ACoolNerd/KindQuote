<template>
    <div>
        <SectionsDemo9Section1 />
        <SectionsDemo9Section2 />
        <SectionsDemo9Section3 />
        <SectionsDemo9Section4 />
        <SectionsDemo9Section5 />
        <SectionsDemo9Section6 />
        <SectionsDemo9Section7 />
        <SectionsDemo9Section8 />
        <SectionsDemo9Section9 />
        <SectionsDemo9Section10 />
        <SectionsDemo9Section11 />
        <SectionsDemo9Section12 />
        <SectionsDemo9Section13 />
        <SectionsDemo9Section14 />
        <SectionsDemo9Section15 />
        <SectionsDemo9Section16 />
        <SectionsDemo9Section17 />
        <SectionsDemo9Section18 />
        <SectionsDemo9Section19 />
        <SectionsDemo9Section20 />
        <SectionsDemo9Section21 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2 scheme-blue"
        },
    })
</script>