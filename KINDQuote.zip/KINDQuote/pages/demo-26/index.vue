<template>
    <div>
        <SectionsDemo26Section1 />
        <SectionsDemo26Section2 />
        <SectionsDemo26Section3 />
        <SectionsDemo26Section4 />
        <SectionsDemo26Section5 />
        <SectionsDemo26Section6 />
        <SectionsDemo26Section7 />
        <SectionsDemo26Section8 />
        <SectionsDemo26Section9 />
        <SectionsDemo26Section10 />
        <SectionsDemo26Section11 />
        <SectionsDemo26Section12 />
        <SectionsDemo26Section13 />
        <SectionsDemo26Section14 />
        <SectionsDemo26Section15 />
        <SectionsDemo26Section16 />
        <SectionsDemo26Section17 />
        <SectionsDemo26Section18 />
        <SectionsDemo26Section19 />
        <SectionsDemo26Section20 />
    </div>
</template>

<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-light scheme-pink"
        },
    })
</script>