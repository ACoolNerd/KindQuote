<template>
    <div>
        <SectionsDemo19Section1 />
        <SectionsDemo19Section2 />
        <SectionsDemo19Section3 />
        <SectionsDemo19Section4 />
        <SectionsDemo19Section5 />
        <SectionsDemo19Section6 />
        <SectionsDemo19Section7 />
        <SectionsDemo19Section8 />
        <SectionsDemo19Section9 />
        <SectionsDemo19Section10 />
        <SectionsDemo19Section11 />
        <SectionsDemo19Section12 />
        <SectionsDemo19Section13 />
        <SectionsDemo19Section14 />
        <SectionsDemo19Section15 />
        <SectionsDemo19Section16 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2 scheme-crocus theme--dark"
        },
    })
</script>