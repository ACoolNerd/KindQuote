<template>
    <div>
        <SectionsDemo20Section1 />
        <SectionsDemo20Section2 />
        <SectionsDemo20Section3 />
        <SectionsDemo20Section4 />
        <SectionsDemo20Section5 />
        <SectionsDemo20Section6 />
        <SectionsDemo20Section7 />
        <SectionsDemo20Section8 />
        <SectionsDemo20Section9 />
        <SectionsDemo20Section10 />
        <SectionsDemo20Section11 />
        <SectionsDemo20Section12 />
        <SectionsDemo20Section13 />
        <SectionsDemo20Section14 />
        <SectionsDemo20Section15 />
        <SectionsDemo20Section16 />
        <SectionsDemo20Section17 />
        <SectionsDemo20Section18 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2 navbar-fill scheme-blue"
        },
    })
</script>