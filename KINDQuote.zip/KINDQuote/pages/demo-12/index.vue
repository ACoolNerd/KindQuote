<template>
    <div>
        <SectionsDemo12Section1 />
        <SectionsDemo12Section2 />
        <SectionsDemo12Section3 />
        <SectionsDemo12Section4 />
        <SectionsDemo12Section5 />
        <SectionsDemo12Section6 />
        <SectionsDemo12Section7 />
        <SectionsDemo12Section8 />
        <SectionsDemo12Section9 />
        <SectionsDemo12Section10 />
        <SectionsDemo12Section11 />
        <SectionsDemo12Section12 />
        <SectionsDemo12Section13 />
        <SectionsDemo12Section14 />
        <SectionsDemo12Section15 />
        <SectionsDemo12Section16 />
        <SectionsDemo12Section17 />
        <SectionsDemo12Section18 />
    </div>
</template>

<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-light scheme-pink"
        },
    })
</script>