<template>
    <div>
        <SectionsDemo1Section1 />
        <SectionsDemo1Section2 />
        <SectionsDemo1Section3 />
        <SectionsDemo1Section4 />
        <SectionsDemo1Section5 />
        <SectionsDemo1Section6 />
        <SectionsDemo1Section7 />
        <SectionsDemo1Section8 />
        <SectionsDemo1Section9 />
        <SectionsDemo1Section10 />
        <SectionsDemo1Section11 />
        <SectionsDemo1Section12 />
        <SectionsDemo1Section13 />
        <SectionsDemo1Section14 />
        <SectionsDemo1Section15 />
        <SectionsDemo1Section16 />
        <SectionsDemo1Section17 />
        <SectionsDemo1Section18 />
        <SectionsDemo1Section19 />
        <SectionsDemo1Section20 />
        <SectionsDemo1Section21 />
    </div>
</template>

<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-light"
        }
    });
</script>
