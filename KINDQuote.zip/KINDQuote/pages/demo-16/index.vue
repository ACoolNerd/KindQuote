<template>
    <div>
        <SectionsDemo16Section1 />
        <SectionsDemo16Section2 />
        <SectionsDemo16Section3 />
        <SectionsDemo16Section4 />
        <SectionsDemo16Section5 />
        <SectionsDemo16Section6 />
        <SectionsDemo16Section7 />
        <SectionsDemo16Section8 />
        <SectionsDemo16Section9 />
        <SectionsDemo16Section10 />
        <SectionsDemo16Section11 />
        <SectionsDemo16Section12 />
        <SectionsDemo16Section13 />
        <SectionsDemo16Section14 />
        <SectionsDemo16Section15 />
        <SectionsDemo16Section16 />
        <SectionsDemo16Section17 />
        <SectionsDemo16Section18 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2 scheme-violet"
        },
    })
</script>