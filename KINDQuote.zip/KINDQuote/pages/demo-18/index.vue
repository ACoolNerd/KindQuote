<template>
    <div>
        <SectionsDemo18Section1 />
        <SectionsDemo18Section2 />
        <SectionsDemo18Section3 />
        <SectionsDemo18Section4 />
        <SectionsDemo18Section5 />
        <SectionsDemo18Section6 />
        <SectionsDemo18Section7 />
        <SectionsDemo18Section8 />
        <SectionsDemo18Section9 />
        <SectionsDemo18Section10 />
        <SectionsDemo18Section11 />
        <SectionsDemo18Section12 />
        <SectionsDemo18Section13 />
        <SectionsDemo18Section14 />
        <SectionsDemo18Section15 />
        <SectionsDemo18Section16 />
        <SectionsDemo18Section17 />
        <SectionsDemo18Section18 />
        <SectionsDemo18Section19 />       
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2 scheme-blue"
        },
    })
</script>