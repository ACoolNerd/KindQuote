<template>
    <div>
        <SectionsDemo24Section1 />
        <SectionsDemo24Section2 />
        <SectionsDemo24Section3 />
        <SectionsDemo24Section4 />
        <SectionsDemo24Section5 />
        <SectionsDemo24Section6 />
        <SectionsDemo24Section7 />
        <SectionsDemo24Section8 />
        <SectionsDemo24Section9 />
        <SectionsDemo24Section10 />
        <SectionsDemo24Section11 />
        <SectionsDemo24Section12 />
        <SectionsDemo24Section13 />
        <SectionsDemo24Section14 />
        <SectionsDemo24Section15 />
        <SectionsDemo24Section16 />
        <SectionsDemo24Section17 />
        <SectionsDemo24Section18 />
        <SectionsDemo24Section19 />
        <SectionsDemo24Section20 />
    </div>
</template>

<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-light scheme-skyblue"
        },
    })
</script>