<template>
    <div>
        <SectionsDemo3Section1 />
        <SectionsDemo3Section2 />
        <SectionsDemo3Section3 />
        <SectionsDemo3Section4 />
        <SectionsDemo3Section5 />
        <SectionsDemo3Section6 />
        <SectionsDemo3Section7 />
        <SectionsDemo3Section8 />
        <SectionsDemo3Section9 />
        <SectionsDemo3Section10 />
        <SectionsDemo3Section11 />
        <SectionsDemo3Section12 />
        <SectionsDemo3Section13 />
        <SectionsDemo3Section14 />
        <SectionsDemo3Section15 />
        <SectionsDemo3Section16 />
        <SectionsDemo3Section17 />
        <SectionsDemo3Section18 />
        <SectionsDemo3Section19 />
        <SectionsDemo3Section20 />
    </div>
</template>

<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-light scheme-blue"
        },
    })
</script>