<template>
    <div>
        <SectionsDemo21Section1 />
        <SectionsDemo21Section2 />
        <SectionsDemo21Section3 />
        <SectionsDemo21Section4 />
        <SectionsDemo21Section5 />
        <SectionsDemo21Section6 />
        <SectionsDemo21Section7 />
        <SectionsDemo21Section8 />
        <SectionsDemo21Section9 />
        <SectionsDemo21Section10 />
        <SectionsDemo21Section11 />
        <SectionsDemo21Section12 />
        <SectionsDemo21Section13 />
        <SectionsDemo21Section14 />
        <SectionsDemo21Section15 />
        <SectionsDemo21Section16 />
        <SectionsDemo21Section17 />
        <SectionsDemo21Section18 />      
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2 scheme-blue"
        },
    })
</script>