<template>
    <div>
        <SectionsAboutSection1 />
        <SectionsAboutSection2 />
        <SectionsAboutSection3 />
        <SectionsAboutSection4 />
        <SectionsAboutSection5 />
        <SectionsAboutSection6 />
        <SectionsAboutSection7 />
        <SectionsAboutSection8 />
        <SectionsAboutSection9 />
        <SectionsAboutSection10 />
        <SectionsAboutSection11 />
        <SectionsAboutSection12 />
        <SectionsAboutSection13 />
        <SectionsAboutSection14 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2"
        },
    })
</script>