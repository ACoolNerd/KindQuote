<template>
    <div>
        <SectionsPricing1Section1 />
        <SectionsPricing1Section2 />
        <SectionsPricing1Section3 />
        <SectionsPricing1Section4 />
        <SectionsPricing1Section5 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2"
        },
    })
</script>