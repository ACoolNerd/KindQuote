<template>
    <div>
        <SectionsDemo7Section1 />
        <SectionsDemo7Section2 />
        <SectionsDemo7Section3 />
        <SectionsDemo7Section4 />
        <SectionsDemo7Section5 />
        <SectionsDemo7Section6 />
        <SectionsDemo7Section7 />
        <SectionsDemo7Section8 />
        <SectionsDemo7Section9 />
        <SectionsDemo7Section10 />
        <SectionsDemo7Section11 />
        <SectionsDemo7Section12 />
        <SectionsDemo7Section13 />
        <SectionsDemo7Section14 />
        <SectionsDemo7Section15 />
        <SectionsDemo7Section16 />
        <SectionsDemo7Section17 />
        <SectionsDemo7Section18 />
    </div>
</template>

<script setup>
    definePageMeta({
        layout: "footer-2",
    })

    useHead({
        bodyAttrs: {
            class: "navbar-dark scheme-crocus"
        },
    })

</script>