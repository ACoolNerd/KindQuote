<template>
    <div>
        <SectionsDemo10Section1 />
        <SectionsDemo10Section2 />
        <SectionsDemo10Section3 />
        <SectionsDemo10Section4 />
        <SectionsDemo10Section5 />
        <SectionsDemo10Section6 />
        <SectionsDemo10Section7 />
        <SectionsDemo10Section8 />
        <SectionsDemo10Section9 />
        <SectionsDemo10Section10 />
        <SectionsDemo10Section11 />
        <SectionsDemo10Section12 />
        <SectionsDemo10Section13 />
        <SectionsDemo10Section14 />
        <SectionsDemo10Section15 />
        <SectionsDemo10Section16 />
        <SectionsDemo10Section17 />
        <SectionsDemo10Section18 />
        <SectionsDemo10Section19 />
        <SectionsDemo10Section20 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2 scheme-magenta"
        },
    })
</script>