<template>
    <div>
        <SectionsLogin1Section1 />
    </div>
</template>

<script setup>
    definePageMeta({
        layout: "no-header-footer",
    })
</script>