<template>
    <div>
        <SectionsDemo25Section1 />
        <SectionsDemo25Section2 />
        <SectionsDemo25Section3 />
        <SectionsDemo25Section4 />
        <SectionsDemo25Section5 />
        <SectionsDemo25Section6 />
        <SectionsDemo25Section7 />
        <SectionsDemo25Section8 />
        <SectionsDemo25Section9 />
        <SectionsDemo25Section10 />
        <SectionsDemo25Section11 />
        <SectionsDemo25Section12 />
        <SectionsDemo25Section13 />
        <SectionsDemo25Section14 />
        <SectionsDemo25Section15 />
        <SectionsDemo25Section16 />
        <SectionsDemo25Section17 />
        <SectionsDemo25Section18 />
        <SectionsDemo25Section19 />
        <SectionsDemo25Section20 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2 scheme-magenta"
        },
    })
</script>