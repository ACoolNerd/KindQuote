<template>
    <div>
        <SectionsDownloadSection1 />
        <SectionsDownloadSection2 />
    </div>
</template>
<script setup>
    useHead({
        bodyAttrs: {
            class: "navbar-dark navbar-dark-2 scheme-blue"
        },
    })
</script>