<template>
    <section id="banner-3" class="pt-100 banner-section">
        <div class="container">
            <!-- BANNER-3 WRAPPER -->
            <div class="banner-3-wrapper bg--05 bg--scroll r-16">
                <div class="banner-overlay">
                    <div class="row">
                        <!-- BANNER-3 TEXT -->
                        <div class="col">
                            <div class="banner-3-txt color--white">
                                <!-- Title -->
                                <h2 class="s-48 w-700">Starting with Martex is easy, fast and free</h2>
                                <!-- Text -->
                                <p class="p-xl">It only takes a few clicks to get started</p>
                                <!-- Button -->
                                <NuxtLink to="/signup-1" class="btn r-04 btn--theme hover--tra-white">Get srarted - it's free</NuxtLink>
                                <!-- Button Text -->
                                <p class="p-sm btn-txt ico-15"><span class="flaticon-check"></span> Free for 14 days, no credit card required.</p>
                            </div>
                        </div>
                        <!-- END BANNER-3 TEXT -->
                    </div>
                    <!-- End row -->
                </div>
                <!-- End banner overlay -->
            </div>
            <!-- END BANNER-3 WRAPPER -->
        </div>
        <!-- End container -->
    </section>
</template>
