<template>
    <div id="rating-1" class="pt-70 rating-section">
        <div class="container">
            <!-- RATING TITLE -->
            <div class="row justify-content-center">
                <div class="col-md-10 col-lg-9">
                    <div class="rating-title mb-40">
                        <h5 class="s-18 color--grey w-500">Our clients love us as much as we love them</h5>
                    </div>
                </div>
            </div>
            <!-- RATING-1 WRAPPER -->
            <div class="rating-1-wrapper">
                <div class="row justify-content-md-center row-cols-1 row-cols-md-3">
                    <!-- RATING BOX #1 -->
                    <div class="col">
                        <div id="rb-1-1" class="rbox-1">
                            <!-- Brand Logo -->
                            <div class="rbox-1-img">
                                <img class="img-fluid" src="/assets/images/brand-21.png" alt="feature-image" />
                            </div>
                            <!-- Rating Stars -->
                            <div class="star-rating ico-10 bg--white-100 r-100 clearfix">
                                <span class="flaticon-star"></span>
                                <span class="flaticon-star"></span>
                                <span class="flaticon-star"></span>
                                <span class="flaticon-star"></span>
                                <span class="flaticon-star-half-empty mr-5"></span>
                                &nbsp; 4.7/5
                            </div>
                        </div>
                    </div>
                    <!-- RATING BOX #2 -->
                    <div class="col">
                        <div id="rb-1-2" class="rbox-1">
                            <!-- Brand Logo -->
                            <div class="rbox-1-img">
                                <img class="img-fluid" src="/assets/images/brand-22.png" alt="feature-image" />
                            </div>
                            <!-- Rating Stars -->
                            <div class="star-rating ico-10 bg--white-100 r-100 clearfix">
                                <span class="flaticon-star"></span>
                                <span class="flaticon-star"></span>
                                <span class="flaticon-star"></span>
                                <span class="flaticon-star"></span>
                                <span class="flaticon-star mr-5"></span>
                                &nbsp; 4.95/5
                            </div>
                        </div>
                    </div>
                    <!-- RATING BOX #3 -->
                    <div class="col">
                        <div id="rb-1-3" class="rbox-1">
                            <!-- Brand Logo -->
                            <div class="rbox-1-img">
                                <img class="img-fluid" src="/assets/images/brand-23.png" alt="feature-image" />
                            </div>
                            <!-- Rating Stars -->
                            <div class="star-rating ico-10 bg--white-100 r-100 clearfix">
                                <span class="flaticon-star"></span>
                                <span class="flaticon-star"></span>
                                <span class="flaticon-star"></span>
                                <span class="flaticon-star"></span>
                                <span class="flaticon-star-1 mr-5"></span>
                                &nbsp; 4.24/5
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End row -->
            </div>
            <!-- END RATING-1 WRAPPER -->
        </div>
        <!-- End container -->
    </div>
    <!-- END RATING-1 -->
    <!-- BANNER-3
			============================================= -->
    <section id="banner-3" class="pt-100 banner-section">
        <div class="container">
            <!-- BANNER-3 WRAPPER -->
            <div class="banner-3-wrapper bg--05 bg--scroll r-16">
                <div class="banner-overlay">
                    <div class="row">
                        <!-- BANNER-3 TEXT -->
                        <div class="col">
                            <div class="banner-3-txt color--white">
                                <!-- Title -->
                                <h2 class="s-48 w-700">Starting with Martex is easy, fast and free</h2>
                                <!-- Text -->
                                <p class="p-xl">It only takes a few clicks to get started</p>
                                <!-- Button -->
                                <NuxtLink to="/signup-1" class="btn r-04 btn--theme hover--tra-white">Get srarted - it's free</NuxtLink>
                                <!-- Button Text -->
                                <p class="p-sm btn-txt ico-15"><span class="flaticon-check"></span> Free for 14 days, no credit card required.</p>
                            </div>
                        </div>
                        <!-- END BANNER-3 TEXT -->
                    </div>
                    <!-- End row -->
                </div>
                <!-- End banner overlay -->
            </div>
            <!-- END BANNER-3 WRAPPER -->
        </div>
        <!-- End container -->
    </section>
</template>
