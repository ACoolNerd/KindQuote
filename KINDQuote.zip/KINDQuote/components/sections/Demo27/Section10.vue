<template>
    <section id="features-12" class="shape--bg shape--white-400 pt-100 features-section division">
        <div class="container">
            <div class="row d-flex align-items-center">
                <!-- TEXT BLOCK -->
                <div class="col-md-5">
                    <div class="txt-block left-column wow fadeInRight">
                        <!-- Title -->
                        <h2 class="s-46 w-700">A single tool for all your needs</h2>
                        <!-- Text -->
                        <p>Sodales tempor sapien quaerat ipsum and congue undo laoreet turpis neque auctor turpis vitae dolor luctus placerat magna ligula and cursus vitae</p>
                        <!-- List -->
                        <ul class="simple-list">
                            <li class="list-item">
                                <p>Tempor sapien quaerat undo ipsum laoreet diam purus sapien a dolor ociis ultrice ipsum aliquam</p>
                            </li>
                            <li class="list-item">
                                <p class="mb-0">Cursus purus suscipit vitae cubilia magnis diam volute egestas sapien ultrice auctor</p>
                            </li>
                        </ul>
                        <!-- Link -->
                        <div class="txt-block-tra-link mt-25">
                            <a href="#features-5" class="tra-link ico-20 color--theme"> Optimize your results <span class="flaticon-next"></span> </a>
                        </div>
                    </div>
                </div>
                <!-- END TEXT BLOCK -->
                <!-- FEATURES-12 WRAPPER -->
                <div class="col-md-7">
                    <div class="fbox-12-wrapper wow fadeInLeft">
                        <div class="row">
                            <div class="col-md-6">
                                <!-- FEATURE BOX #1 -->
                                <div id="fb-12-1" class="fbox-12 bg--white-100 block-shadow r-12 mb-30">
                                    <!-- Icon -->
                                    <div class="fbox-ico ico-50">
                                        <div class="shape-ico color--theme">
                                            <!-- Vector Icon -->
                                            <span class="flaticon-maximize"></span>
                                            <!-- Shape -->
                                            <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M69.8,-23C76.3,-2.7,57.6,25.4,32.9,42.8C8.1,60.3,-22.7,67,-39.1,54.8C-55.5,42.7,-57.5,11.7,-48.6,-11.9C-39.7,-35.5,-19.8,-51.7,5.9,-53.6C31.7,-55.6,63.3,-43.2,69.8,-23Z" transform="translate(100 100)" />
                                            </svg>
                                        </div>
                                    </div>
                                    <!-- End Icon -->
                                    <!-- Text -->
                                    <div class="fbox-txt">
                                        <h5 class="s-19 w-700">Cross-Platform</h5>
                                        <p>Porta semper lacus and cursus feugiat at primis ultrice a ligula auctor</p>
                                    </div>
                                </div>
                                <!-- FEATURE BOX #2 -->
                                <div id="fb-12-2" class="fbox-12 bg--white-100 block-shadow r-12">
                                    <!-- Icon -->
                                    <div class="fbox-ico ico-50">
                                        <div class="shape-ico color--theme">
                                            <!-- Vector Icon -->
                                            <span class="flaticon-manager"></span>
                                            <!-- Shape -->
                                            <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M69.8,-23C76.3,-2.7,57.6,25.4,32.9,42.8C8.1,60.3,-22.7,67,-39.1,54.8C-55.5,42.7,-57.5,11.7,-48.6,-11.9C-39.7,-35.5,-19.8,-51.7,5.9,-53.6C31.7,-55.6,63.3,-43.2,69.8,-23Z" transform="translate(100 100)" />
                                            </svg>
                                        </div>
                                    </div>
                                    <!-- End Icon -->
                                    <!-- Text -->
                                    <div class="fbox-txt">
                                        <h5 class="s-19 w-700">Multiple Accounts</h5>
                                        <p>Porta semper lacus and cursus feugiat at primis ultrice a ligula auctor</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <!-- FEATURE BOX #3 -->
                                <div id="fb-12-3" class="fbox-12 bg--white-100 block-shadow r-12 mb-30">
                                    <!-- Icon -->
                                    <div class="fbox-ico ico-50">
                                        <div class="shape-ico color--theme">
                                            <!-- Vector Icon -->
                                            <span class="flaticon-rotate"></span>
                                            <!-- Shape -->
                                            <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M69.8,-23C76.3,-2.7,57.6,25.4,32.9,42.8C8.1,60.3,-22.7,67,-39.1,54.8C-55.5,42.7,-57.5,11.7,-48.6,-11.9C-39.7,-35.5,-19.8,-51.7,5.9,-53.6C31.7,-55.6,63.3,-43.2,69.8,-23Z" transform="translate(100 100)" />
                                            </svg>
                                        </div>
                                    </div>
                                    <!-- End Icon -->
                                    <!-- Text -->
                                    <div class="fbox-txt">
                                        <h5 class="s-19 w-700">Extremely Flexible</h5>
                                        <p>Porta semper lacus and cursus feugiat at primis ultrice a ligula auctor</p>
                                    </div>
                                </div>
                                <!-- FEATURE BOX #4 -->
                                <div id="fb-12-4" class="fbox-12 bg--white-100 block-shadow r-12">
                                    <!-- Icon -->
                                    <div class="fbox-ico ico-50">
                                        <div class="shape-ico color--theme">
                                            <!-- Vector Icon -->
                                            <span class="flaticon-prioritize"></span>
                                            <!-- Shape -->
                                            <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M69.8,-23C76.3,-2.7,57.6,25.4,32.9,42.8C8.1,60.3,-22.7,67,-39.1,54.8C-55.5,42.7,-57.5,11.7,-48.6,-11.9C-39.7,-35.5,-19.8,-51.7,5.9,-53.6C31.7,-55.6,63.3,-43.2,69.8,-23Z" transform="translate(100 100)" />
                                            </svg>
                                        </div>
                                    </div>
                                    <!-- End Icon -->
                                    <!-- Text -->
                                    <div class="fbox-txt">
                                        <h5 class="s-19 w-700">Easy to Embed</h5>
                                        <p>Porta semper lacus and cursus feugiat at primis ultrice a ligula auctor</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End row -->
                </div>
                <!-- END FEATURES-12 WRAPPER -->
            </div>
            <!-- End row -->
        </div>
        <!-- End container -->
    </section>
</template>
