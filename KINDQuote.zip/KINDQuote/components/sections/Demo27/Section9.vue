<template>
    <section id="lnk-3" class="pt-100 ct-02 content-section division">
        <div class="container">
            <!-- SECTION TITLE -->
            <div class="row justify-content-center">
                <div class="col-md-10 col-lg-9">
                    <div class="section-title mb-80">
                        <!-- Title -->
                        <h2 class="s-50 w-700">Marketing Integrations</h2>
                        <!-- Text -->
                        <p class="s-21 color--grey">Ligula risus auctor tempus magna feugiat lacinia.</p>
                    </div>
                </div>
            </div>
            <!-- SECTION CONTENT (ROW) -->
            <div class="row d-flex align-items-center">
                <!-- IMAGE BLOCK -->
                <div class="col-md-6">
                    <div class="img-block left-column wow fadeInRight">
                        <img class="img-fluid" src="/assets/images/img-02.png" alt="content-image" />
                    </div>
                </div>
                <!-- TEXT BLOCK -->
                <div class="col-md-6">
                    <div class="txt-block right-column wow fadeInLeft">
                        <!-- TEXT BOX -->
                        <div class="txt-box">
                            <!-- Title -->
                            <h5 class="s-24 w-700">Integrate with popular tools</h5>
                            <!-- Text -->
                            <p>Sodales tempor sapien quaerat ipsum undo congue laoreet turpis neque auctor turpis vitae dolor luctus placerat magna and ligula cursus purus vitae purus an ipsum suscipit</p>
                        </div>
                        <!-- END TEXT BOX -->
                        <!-- TEXT BOX -->
                        <div class="txt-box mb-0">
                            <!-- Title -->
                            <h5 class="s-24 w-700">Automate data collection</h5>
                            <!-- List -->
                            <ul class="simple-list">
                                <li class="list-item">
                                    <p>Tempor sapien quaerat an ipsum laoreet purus and sapien dolor an ultrice ipsum aliquam undo congue dolor cursus</p>
                                </li>
                                <li class="list-item">
                                    <p class="mb-0">Cursus purus suscipit vitae cubilia magnis volute egestas vitae sapien turpis ultrice auctor congue magna placerat</p>
                                </li>
                            </ul>
                        </div>
                        <!-- END TEXT BOX -->
                    </div>
                </div>
                <!-- END TEXT BLOCK -->
            </div>
            <!-- END SECTION CONTENT (ROW) -->
        </div>
        <!-- End container -->
    </section>
</template>
