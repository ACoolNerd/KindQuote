<template>
    <section id="hero-18" class="bg--scroll hero-section">
        <div class="container">
            <div class="row d-flex align-items-center">
                <!-- HERO IMAGE -->
                <div class="col-md-6 order-last order-md-2">
                    <div class="hero-18-img wow fadeInRight">
                        <img class="img-fluid" src="/assets/images/hero-18-img.png" alt="hero-image" />
                    </div>
                </div>
                <!-- HERO TEXT -->
                <div class="col-md-6 order-first order-md-2">
                    <div class="hero-18-txt wow fadeInLeft">
                        <!-- Title -->
                        <h2 class="s-56 w-700">Monitor all progress of your workflow easily</h2>
                        <!-- Text -->
                        <p class="p-xl">Mauris donec turpis suscipit sapien ociis sagittis sapien tempor a volute ligula and aliquet tortor</p>
                        <!-- HERO QUICK FORM -->
                        <form name="quickform" class="quick-form form-shadow form-half mt-35">
                            <!-- Form Inputs -->
                            <div class="input-group">
                                <input type="email" name="email" class="form-control email r-06" placeholder="Your email address" autocomplete="off" required />
                                <span class="input-group-btn form-btn">
                                    <button type="submit" class="btn r-06 btn--theme hover--theme submit">Get Started</button>
                                </span>
                            </div>
                            <!-- Form Message -->
                            <div class="quick-form-msg"><span class="loading"></span></div>
                        </form>
                        <!-- Text -->
                        <p class="p-sm btn-txt ico-15"><span class="flaticon-check"></span> No credit card needed, free 14-day trial</p>
                    </div>
                </div>
                <!-- END HERO TEXT -->
            </div>
            <!-- End row -->
        </div>
        <!-- End container -->
    </section>
</template>
