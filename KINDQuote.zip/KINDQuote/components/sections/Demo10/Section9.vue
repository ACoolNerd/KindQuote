<template>
    <section class="pt-100 ct-02 content-section division">
        <div class="container">
            <!-- SECTION CONTENT (ROW) -->
            <div class="row d-flex align-items-center">
                <!-- IMAGE BLOCK -->
                <div class="col-md-6">
                    <div class="img-block left-column wow fadeInRight">
                        <img class="img-fluid" src="/assets/images/img-10.png" alt="content-image" />
                    </div>
                </div>
                <!-- TEXT BLOCK -->
                <div class="col-md-6">
                    <div class="txt-block right-column wow fadeInLeft">
                        <!-- CONTENT BOX #1 -->
                        <div class="cbox-2 process-step">
                            <!-- Icon -->
                            <div class="ico-wrap">
                                <div class="cbox-2-ico bg--theme color--white">1</div>
                                <span class="cbox-2-line"></span>
                            </div>
                            <!-- Text -->
                            <div class="cbox-2-txt">
                                <h5 class="s-22 w-700">Password Protection</h5>
                                <p>Ligula risus auctor tempus feugiat dolor lacinia nemo purus in lipsum purus sapien quaerat a primis viverra tellus vitae luctus dolor ipsum neque ligula quaerat</p>
                            </div>
                        </div>
                        <!-- END CONTENT BOX #1 -->
                        <!-- CONTENT BOX #2 -->
                        <div class="cbox-2 process-step">
                            <!-- Icon -->
                            <div class="ico-wrap">
                                <div class="cbox-2-ico bg--theme color--white">2</div>
                                <span class="cbox-2-line"></span>
                            </div>
                            <!-- Text -->
                            <div class="cbox-2-txt">
                                <h5 class="s-22 w-700">Multi-Device Syncing</h5>
                                <p>Ligula risus auctor tempus feugiat dolor lacinia nemo purus in lipsum purus sapien quaerat a primis viverra tellus vitae luctus dolor ipsum neque ligula quaerat</p>
                            </div>
                        </div>
                        <!-- END CONTENT BOX #2 -->
                        <!-- CONTENT BOX #3 -->
                        <div class="cbox-2 process-step">
                            <!-- Icon -->
                            <div class="ico-wrap">
                                <div class="cbox-2-ico bg--theme color--white">3</div>
                            </div>
                            <!-- Text -->
                            <div class="cbox-2-txt">
                                <h5 class="s-22 w-700">Effortless File Sharing</h5>
                                <p class="mb-0">Ligula risus auctor tempus feugiat dolor lacinia nemo purus in lipsum purus sapien quaerat a primis viverra tellus vitae luctus dolor ipsum neque ligula quaerat</p>
                            </div>
                        </div>
                        <!-- END CONTENT BOX #3 -->
                    </div>
                </div>
                <!-- END TEXT BLOCK -->
            </div>
            <!-- END SECTION CONTENT (ROW) -->
        </div>
        <!-- End container -->
    </section>
</template>
