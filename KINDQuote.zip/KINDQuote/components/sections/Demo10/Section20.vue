<template>
<!-- NEWSLETTER-1
			============================================= -->
			<section id="newsletter-1" class="newsletter-section">
				<div class="newsletter-overlay">
					<div class="container">
						<div class="row d-flex align-items-center row-cols-1 row-cols-lg-2">
							<!-- NEWSLETTER TEXT -->
							<div class="col">
								<div class="newsletter-txt">
									<h4 class="s-34 w-700">Stay up to date with our news, ideas and updates</h4>
								</div>
							</div>
							<!-- NEWSLETTER FORM -->
							<div class="col">
								<form class="newsletter-form">
									<div class="input-group">
										<input type="email" autocomplete="off" class="form-control" placeholder="Your email address" required id="s-email">
										<span class="input-group-btn">
											<button type="submit" class="btn btn--theme hover--theme">Subscribe Now</button>
										</span>
									</div>
									<!-- Newsletter Form Notification -->
									<label for="s-email" class="form-notification"></label>
								</form>
							</div>	  <!-- END NEWSLETTER FORM -->
						</div>	  <!-- End row -->
					</div>    <!-- End container -->
				</div>     <!-- End newsletter-overlay -->
			</section>	<!-- END NEWSLETTER-1 -->
			<!-- DIVIDER LINE -->
			<hr class="divider">
</template>
