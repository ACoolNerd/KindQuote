<template>
    <section id="lnk-1" class="pt-100 ws-wrapper content-section">
        <div class="container">
            <div class="bc-3-wrapper bg--04 bg--fixed hidd r-16">
                <div class="section-overlay">
                    <div class="row d-flex align-items-center">
                        <!-- TEXT BLOCK -->
                        <div class="col-md-6 col-lg-5 order-last order-md-2">
                            <div class="bc-3-txt wow fadeInRight">
                                <!-- Section ID -->
                                <span class="section-id">Advanced Security</span>
                                <!-- Title -->
                                <h2 class="s-44 w-700">Secure access to all your files</h2>
                                <!-- Text -->
                                <p class="mb-0">Risus auctor ligula tempus feugiat and dolor lacinia purus in congue lipsum purus sapien quaerat vitae primis tellus viverra vitae</p>
                                <!-- Link -->
                                <div class="txt-block-tra-link mt-25">
                                    <a href="#features-2" class="tra-link ico-20 color--theme"> The smarter way to work <span class="flaticon-next"></span> </a>
                                </div>
                            </div>
                        </div>
                        <!-- END TEXT BLOCK -->
                        <!-- IMAGE BLOCK -->
                        <div class="col-md-6 col-lg-7 order-first order-md-2">
                            <div class="bc-3-img wow fadeInLeft">
                                <img class="img-fluid" src="/assets/images/dashboard-05.png" alt="content-image" />
                            </div>
                        </div>
                    </div>
                    <!-- End row -->
                </div>
                <!-- End section overlay -->
            </div>
            <!-- End content wrapper -->
        </div>
        <!-- End container -->
    </section>
</template>
