<template>
    <section class="page-hero-section">
        <div class="page-hero-section-overlay bg--01 bg--scroll">
            <div class="container">
                <div class="row d-flex align-items-center">
                    <!-- TEXT BLOCK -->
                    <div class="col-md-6">
                        <div class="txt-block left-column color--white wow fadeInRight">
                            <!-- Section ID -->
                            <span class="section-id rounded-id bg--tra-white color--white"> Careers </span>
                            <!-- Title -->
                            <h2 class="s-56 w-700">We are looking for creative and fun individuals</h2>
                            <!-- Text -->
                            <p class="p-lg w-400">Sodales tempor sapien quaerat ipsum congue undo laoreet turpis neque auctor turpis vitae dolor luctus placerat magna ipsun ligula purus cursus</p>
                        </div>
                    </div>
                    <!-- END TEXT BLOCK -->
                    <!-- IMAGE BLOCK -->
                    <div class="col-md-6">
                        <div class="img-block right-column wow fadeInLeft">
                            <img class="img-fluid" src="/assets/images/img-18.png" alt="content-image" />
                        </div>
                    </div>
                </div>
                <!-- End row -->
            </div>
            <!-- End container -->
        </div>
        <!-- End Page Hero Section Overlay -->
        <!-- WAVE SHAPE BOTTOM -->
        <div class="wave-shape-bottom">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 170"><path fill-opacity="1" d="M0,160L120,160C240,160,480,160,720,138.7C960,117,1200,75,1320,53.3L1440,32L1440,320L1320,320C1200,320,960,320,720,320C480,320,240,320,120,320L0,320Z"></path></svg>
        </div>
    </section>
</template>
