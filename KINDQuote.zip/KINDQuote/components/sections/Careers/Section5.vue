<template>
    <section class="bg--white-400 py-100 ct-01 content-section division">
        <div class="container">
            <div class="row d-flex align-items-center">
                <!-- TEXT BLOCK -->
                <div class="col-md-6 order-last order-md-2">
                    <div class="txt-block left-column wow fadeInRight">
                        <!-- Section ID -->
                        <span class="section-id">Co-founder at Martex</span>
                        <!-- Title -->
                        <h2 class="s-48 w-700">Henry Adams</h2>
                        <!-- Text -->
                        <p class="p-lg mb-0">&quot;Sodales tempor sapien diam purus ipsum quaerat and volute fusce a congue laoreet turpis neque diam auctor turpis vitae dolor magna luctus placerat neque ipsum fusce cursus ligula cursus purus vitae purus and ipsum suscipit. Nemo ipsam cubilia donec turpis undo egestas ipsum a purus sapien ultrice aliquam lacus and quaerat an ipsum augue turpis sapien cursus congue augue&quot;</p>
                    </div>
                </div>
                <!-- END TEXT BLOCK -->
                <!-- IMAGE BLOCK -->
                <div class="col-md-6 order-first order-md-2">
                    <div class="img-block j-img video-preview right-column wow fadeInLeft">
                        <!-- Play Icon -->
                        <ElementsCustomModalVideo />
                        <!-- Preview Image -->
                        <img class="img-fluid r-20" src="/assets/images/img-17.jpg" alt="video-preview" />
                    </div>
                </div>
            </div>
            <!-- End row -->
        </div>
        <!-- End container -->
    </section>
</template>
