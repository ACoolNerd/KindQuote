<template>
    <div class="py-100 page-pagination theme-pagination">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <ElementsPagination />
                </div>
            </div>
            <!-- End row -->
        </div>
        <!-- End container -->
    </div>

    <hr class="divider" />
</template>
