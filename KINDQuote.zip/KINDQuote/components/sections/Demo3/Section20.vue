<template>
    <div id="modal-1" class="modal fade" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <!-- CLOSE BUTTON -->
                <button type="button" class="btn-close ico-10 white-color" data-bs-dismiss="modal" aria-label="Close">
                    <span class="flaticon-cancel"></span>
                </button>
                <!-- MODAL CONTENT -->
                <div class="bg-img rounded">
                    <div class="overlay-light">
                        <div class="modal-img text-center">
                            <NuxtLink to="/pricing-1">
                                <img class="img-fluid" src="/assets/images/modal-1-img.jpg" alt="modal-image" />
                            </NuxtLink>
                        </div>
                    </div>
                </div>
                <!-- END MODAL CONTENT -->
            </div>
        </div>
    </div>
</template>
