<template>
    <section class="pt-100 ct-03 content-section division">
        <div class="container">
            <div class="row d-flex align-items-center">
                <!-- IMAGE BLOCK -->
                <div class="col-md-6 col-lg-7">
                    <div class="img-block left-column wow fadeInRight">
                        <img class="img-fluid" src="/assets/images/img-14.png" alt="content-image" />
                    </div>
                </div>
                <!-- TEXT BLOCK -->
                <div class="col-md-6 col-lg-5">
                    <div class="txt-block right-column wow fadeInLeft">
                        <!-- Section ID -->
                        <span class="section-id">Engagement Analytics</span>
                        <!-- Title -->
                        <h2 class="s-46 w-700">Data-driven digital marketing</h2>
                        <!-- List -->
                        <ul class="simple-list">
                            <li class="list-item">
                                <p>Tempor sapien quaerat undo ipsum laoreet purus and sapien dolor ociis ultrice ipsum aliquam undo congue dolor cursus congue varius magnis</p>
                            </li>
                            <li class="list-item">
                                <p class="mb-0">Cursus purus suscipit vitae cubilia magnis diam volute egestas sapien ultrice auctor</p>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- END TEXT BLOCK -->
            </div>
            <!-- End row -->
        </div>
        <!-- End container -->
    </section>
</template>
