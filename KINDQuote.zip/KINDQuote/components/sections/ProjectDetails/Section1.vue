<template>
    <section id="project-1" class="gr--whitesmoke inner-page-hero single-project">
        <div class="container">
            <div class="row justify-content-center">
                <!-- PROJECT DISCRIPTION -->
                <div class="col-lg-11 col-xl-10">
                    <div class="project-description">
                        <!-- PROJECT TITLE -->
                        <div class="project-title">
                            <!-- Title -->
                            <h2 class="s-52 w-700">Online shopping concept for mobile app templates</h2>
                            <!-- Project Data -->
                            <div class="project-data">
                                <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3">
                                    <div class="col">
                                        <p class="p-lg"><span>Category:</span> Development</p>
                                    </div>
                                    <div class="col">
                                        <p class="p-lg"><span>Start Date:</span> 2024-02-28</p>
                                    </div>
                                    <div class="col">
                                        <p class="p-lg"><span>Handover:</span> 2024-04-30</p>
                                    </div>
                                    <div class="col">
                                        <p class="p-lg"><span>Client:</span> DSAThemes</p>
                                    </div>
                                    <div class="col">
                                        <p class="p-lg"><a href="#" class="color--theme">www.website.com</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- END PROJECT TITLE -->
                        <!-- PROJECT PREVIEW IMAGE  -->
                        <div class="project-priview-img mb-50">
                            <img class="img-fluid r-16" src="/assets/images/projects/project-07.jpg" alt="project-preview" />
                        </div>
                        <!-- PROJECT TEXT -->
                        <div class="project-txt">
                            <!-- Text -->
                            <p>Integer congue sagittis augue egestas velna purus purus magna nec suscipit and egestas magna aliquam ipsum vitae purus justo lacus ligula ipsum primis cubilia donec undo augue luctus vitae egestas a molestie donec libero sapien dapibus congue tempor undo quisque fusce cursus neque diam augue fusce sapien nulla a primis lacinia ipsum a molestie blandit and justo an aliquet eget molestie sagittis at quaerat sodales</p>
                            <!-- List -->
                            <ul class="simple-list">
                                <li class="list-item">
                                    <p>Quaerat sodales sapien undo velna purus euismod purus velna blandit vitae auctor and congue magna tempor sapien gravida laoreet turpis urna augue, viverra a augue eget tempor diam</p>
                                </li>
                                <li class="list-item">
                                    <p>Nemo ipsam egestas volute turpis dolores ut aliquam quaerat sodales sapien congue and augue egestas</p>
                                </li>
                            </ul>
                            <!-- Small Title -->
                            <h5 class="s-24 w-700 mt-35 mb-35">Overview & Challenge</h5>
                            <!-- Text -->
                            <p>Congue sagittis augue egestas integer velna purus purus magna nec suscipit and egestas magna aliquam ipsum vitae purus justo lacus ligula ipsum primis cubilia donec undo augue luctus vitae egestas a molestie donec libero sapien dapibus congue tempor undo quisque fusce cursus neque blandit fusce aliquam</p>
                            <!-- Text -->
                            <p>Congue augue sagittis egestas integer velna purus purus magna nec suscipit and egestas magna aliquam ipsum vitae purus justo lacus ligula ipsum primis cubilia donec undo augue luctus vitae egestas a molestie donec libero sapien dapibus congue tempor undo quisque fusce cursus neque blandit fusce lorem nulla an aliquam lacinia justo molestie blandit justo diam an aliquet tortor sagittis lacinia molestie diam egestas</p>
                            <!-- List -->
                            <ul class="simple-list">
                                <li class="list-item">
                                    <p>Quaerat sodales sapien undo velna purus euismod purus velna blandit vitae auctor and congue magna tempor sapien gravida laoreet turpis urna augue, viverra a augue eget tempor diam</p>
                                </li>
                                <li class="list-item">
                                    <p>Nemo ipsam egestas volute turpis dolores ut aliquam quaerat sodales sapien congue and augue egestas</p>
                                </li>
                            </ul>
                            <!-- PROJECT IMAGES -->
                            <div class="row d-flex align-items-center project-inner-img mt-50">
                                <!-- IMAGE #1 -->
                                <div class="col-md-6">
                                    <div class="project-image project-preview top-img r-10">
                                        <!-- Project Preview -->
                                        <div class="hover-overlay">
                                            <img class="img-fluid" src="/assets/images/projects/project-10.jpg" alt="project-preview" />
                                            <div class="item-overlay"></div>
                                        </div>
                                        <!-- Project Link -->
                                        <div class="project-link ico-35 color--white">
                                            <a class="image-link" href="images/projects/project-10a.jpg" title="">
                                                <span class="flaticon-visibility"></span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <!-- IMAGE #2 -->
                                <div class="col-md-6">
                                    <div class="project-image project-preview r-10">
                                        <!-- Project Preview -->
                                        <div class="hover-overlay">
                                            <img class="img-fluid" src="/assets/images/projects/project-11.jpg" alt="project-preview" />
                                            <div class="item-overlay"></div>
                                        </div>
                                        <!-- Project Link -->
                                        <div class="project-link ico-35 color--white">
                                            <a class="image-link" href="images/projects/project-11a.jpg" title="">
                                                <span class="flaticon-visibility"></span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- END PROJECT IMAGES -->
                            <!-- WIDE IMAGE -->
                            <div class="project-inner-img mt-30">
                                <div class="project-image project-preview r-10">
                                    <!-- Project Preview -->
                                    <div class="hover-overlay">
                                        <img class="img-fluid" src="/assets/images/projects/project-08.jpg" alt="project-preview" />
                                        <div class="item-overlay"></div>
                                    </div>
                                    <!-- Project Link -->
                                    <div class="project-link ico-35 color--white">
                                        <a class="image-link" href="images/projects/project-08.jpg" title="">
                                            <span class="flaticon-visibility"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <!-- END WIDE IMAGE -->
                            <!-- Small Title -->
                            <h5 class="s-24 w-700 mt-50 mb-35">Project Summary</h5>
                            <!-- Text -->
                            <p>Congue augue sagittis egestas integer velna purus purus magna nec suscipit and egestas magna aliquam ipsum vitae purus justo lacus ligula ipsum primis cubilia donec undo augue luctus vitae egestas a molestie donec libero sapien dapibus congue tempor undo quisque fusce cursus neque blandit fusce lorem nulla an aliquam lacinia justo molestie blandit justo diam an aliquet tortor sagittis lacinia molestie diam egestas</p>
                            <!-- List -->
                            <ul class="simple-list long-list mb-20">
                                <li class="list-item">
                                    <p>Aliqum mullam blandit tempor sapien gravida donec ipsum porta justo. Laoreet turpis urna augue, viverra a augue eget, dictum tempor diam pulvinar dictum tempor</p>
                                </li>
                                <li class="list-item">
                                    <p>Blandit velna vitae auctor and congue magna tempor sapien eget gravida laoreet turpis</p>
                                </li>
                                <li class="list-item">
                                    <p>Nemo ipsam egestas volute turpis dolores ut aliquam quaerat sodales sapien congue augue egestas</p>
                                </li>
                            </ul>
                            <!-- Text -->
                            <p>Sagittis augue congue egestas integer velna purus purus magna nec suscipit and egestas magna aliquam ipsum vitae purus justo lacus ligula ipsum primis cubilia donec undo augue luctus vitae egestas a molestie donec libero sapien dapibus congue tempor undo quisque fusce cursus neque aliquam fusce blandit</p>
                            <!-- VIDEO PREVIEW -->
                            <div class="project-image project-inner-img video-preview mt-50">
                                <!-- Play Icon -->
                                <ElementsCustomModalVideo />
                                <!-- Preview Image -->
                                <img class="img-fluid r-10" src="/assets/images/projects/project-09.jpg" alt="video-preview" />
                            </div>
                            <!-- END VIDEO PREVIEW -->
                            <!-- Small Title -->
                            <h5 class="s-24 w-700 mt-50 mb-35">Solution & Results</h5>
                            <!-- Text -->
                            <p>Sagittis congue augue egestas integer velna purus purus magna nec suscipit and egestas magna aliquam ipsum vitae purus justo lacus ligula ipsum primis cubilia donec undo augue luctus vitae egestas a molestie donec libero sapien dapibus congue tempor undo quisque fusce cursus neque blandit fusce lacinia placerat and nulla justo molestie blandit justo diam aliquet tortor molestie sagittis lacinia undo and mullam molestie diam luctus donec bibendum aliquet massa elementum. Libero quisque lacus and ligula massa lorem</p>
                            <!-- List -->
                            <ul class="simple-list long-list mb-20">
                                <li class="list-item">
                                    <p>Sagittis congue augue egestas volutpat egestas magna suscipit egestas magna ipsum and vitae efficitur purus and ipsum primis in cubilia laoreet augue egestas luctus donec.</p>
                                </li>
                                <li class="list-item">
                                    <p>Aliqum mullam blandit tempor sapien gravida donec ipsum porta justo. Laoreet turpis urna augue, viverra a augue eget, dictum tempor diam pulvinar dictum tempor</p>
                                </li>
                            </ul>
                            <!-- Text -->
                            <p>Sagittis augue congue egestas integer velna purus purus magna nec suscipit and egestas magna aliquam ipsum vitae purus justo lacus ligula ipsum primis cubilia donec undo augue luctus vitae egestas a molestie donec libero sapien dapibus congue tempor undo quisque fusce cursus neque aliquam fusce blandit</p>
                        </div>
                        <!-- END PROJECT TEXT -->
                        <!-- MORE PROJECTS BUTTON -->
                        <div class="more-projects ico-25 text-end pb-100">
                            <NuxtLink to="/projects">
                                <h3 class="s-38 w-700">More Projects</h3>
                                <span class="flaticon-next"></span>
                            </NuxtLink>
                        </div>
                    </div>
                </div>
                <!-- END PROJECT DISCRIPTION -->
            </div>
            <!-- End row -->
        </div>
        <!-- End container -->
    </section>
</template>
