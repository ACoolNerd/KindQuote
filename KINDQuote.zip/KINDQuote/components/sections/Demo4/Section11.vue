<template>
    <section class="pt-100 ct-03 content-section division">
        <div class="container">
            <div class="row d-flex align-items-center">
                <!-- IMAGE BLOCK -->
                <div class="col-md-6 col-lg-7">
                    <div class="img-block left-column wow fadeInRight">
                        <img class="img-fluid" src="/assets/images/img-14.png" alt="content-image" />
                    </div>
                </div>
                <!-- TEXT BLOCK -->
                <div class="col-md-6 col-lg-5">
                    <div class="txt-block right-column wow fadeInLeft">
                        <!-- CONTENT BOX #1 -->
                        <div class="cbox-2 process-step">
                            <!-- Icon -->
                            <div class="ico-wrap">
                                <div class="cbox-2-ico bg--theme color--white">1</div>
                                <span class="cbox-2-line"></span>
                            </div>
                            <!-- Text -->
                            <div class="cbox-2-txt">
                                <h5 class="s-22 w-700">Built-In Automation</h5>
                                <p>Ligula risus auctor tempus feugiat dolor lacinia a purus lipsum purus and auctor</p>
                            </div>
                        </div>
                        <!-- END CONTENT BOX #1 -->
                        <!-- CONTENT BOX #2 -->
                        <div class="cbox-2 process-step">
                            <!-- Icon -->
                            <div class="ico-wrap">
                                <div class="cbox-2-ico bg--theme color--white">2</div>
                                <span class="cbox-2-line"></span>
                            </div>
                            <!-- Text -->
                            <div class="cbox-2-txt">
                                <h5 class="s-22 w-700">Powerful Search</h5>
                                <p>Ligula risus auctor tempus feugiat dolor lacinia a purus eget lipsum purus sapien quaerat diam primis tellus vitae</p>
                            </div>
                        </div>
                        <!-- END CONTENT BOX #2 -->
                        <!-- CONTENT BOX #3 -->
                        <div class="cbox-2 process-step">
                            <!-- Icon -->
                            <div class="ico-wrap">
                                <div class="cbox-2-ico bg--theme color--white">3</div>
                            </div>
                            <!-- Text -->
                            <div class="cbox-2-txt">
                                <h5 class="s-22 w-700">Password Protection</h5>
                                <p class="mb-0">Ligula risus auctor tempus feugiat dolor lacinia a purus lipsum purus and auctor</p>
                            </div>
                        </div>
                        <!-- END CONTENT BOX #3 -->
                    </div>
                </div>
                <!-- END TEXT BLOCK -->
            </div>
            <!-- End row -->
        </div>
        <!-- End container -->
    </section>
</template>
