<template>
    <section id="features-2" class="py-100 features-section division">
        <div class="container">
            <!-- SECTION TITLE -->
            <div class="row justify-content-center">
                <div class="col-md-10 col-lg-9">
                    <div class="section-title mb-70">
                        <!-- Title -->
                        <h2 class="s-50 w-700">The Complete Solutions</h2>
                        <!-- Text -->
                        <p class="s-21 color--grey">Ligula risus auctor tempus magna feugiat lacinia.</p>
                    </div>
                </div>
            </div>
            <!-- FEATURES-2 WRAPPER -->
            <div class="fbox-wrapper text-center">
                <div class="row row-cols-1 row-cols-md-3">
                    <!-- FEATURE BOX #1 -->
                    <div class="col">
                        <div class="fbox-2 fb-1 wow fadeInUp">
                            <!-- Image -->
                            <div class="fbox-img gr--whitesmoke h-175">
                                <img class="img-fluid" src="/assets/images/f_01.png" alt="feature-image" />
                            </div>
                            <!-- Text -->
                            <div class="fbox-txt">
                                <h6 class="s-22 w-700">Friendly Interface</h6>
                                <p>Luctus egestas augue undo ultrice aliquam in lacus congue dapibus</p>
                            </div>
                        </div>
                    </div>
                    <!-- END FEATURE BOX #1 -->
                    <!-- FEATURE BOX #2 -->
                    <div class="col">
                        <div class="fbox-2 fb-2 wow fadeInUp">
                            <!-- Image -->
                            <div class="fbox-img gr--whitesmoke h-175">
                                <img class="img-fluid" src="/assets/images/f_06.png" alt="feature-image" />
                            </div>
                            <!-- Text -->
                            <div class="fbox-txt">
                                <h6 class="s-22 w-700">Extensions & Addons</h6>
                                <p>Tempor laoreet augue undo ultrice aliquam in lacusq luctus feugiat</p>
                            </div>
                        </div>
                    </div>
                    <!-- END FEATURE BOX #2 -->
                    <!-- FEATURE BOX #3 -->
                    <div class="col">
                        <div class="fbox-2 fb-3 wow fadeInUp">
                            <!-- Image -->
                            <div class="fbox-img gr--whitesmoke h-175">
                                <img class="img-fluid" src="/assets/images/f_08.png" alt="feature-image" />
                            </div>
                            <!-- Text -->
                            <div class="fbox-txt">
                                <h6 class="s-22 w-700">Flexible Editor</h6>
                                <p>Egestas luctus augue undo ultrice aliquam in lacus feugiat cursus</p>
                            </div>
                        </div>
                    </div>
                    <!-- END FEATURE BOX #3 -->
                </div>
                <!-- End row -->
            </div>
            <!-- END FEATURES-2 WRAPPER -->
        </div>
        <!-- End container -->
    </section>
</template>
