<template>
    <section id="lnk-2" class="pt-100 ws-wrapper content-section">
        <div class="container">
            <div class="bc-5-wrapper bg--04 hidd bg--fixed r-16">
                <div class="section-overlay">
                    <!-- SECTION TITLE -->
                    <div class="row justify-content-center">
                        <div class="col-md-11 col-lg-9">
                            <div class="section-title wow fadeInUp mb-60">
                                <!-- Title -->
                                <h2 class="s-52 w-700">Find inspiration for your next design project</h2>
                                <!-- Text -->
                                <p class="p-xl">Aliquam a augue suscipit luctus neque purus ipsum neque diam dolor primis libero tempus, blandit and cursus varius and magnis sodales</p>
                            </div>
                        </div>
                    </div>
                    <!-- IMAGE BLOCK -->
                    <div class="row justify-content-center">
                        <div class="col">
                            <div class="bc-5-img bc-5-tablet img-block-hidden video-preview wow fadeInUp">
                                <!-- Play Icon -->
                                <ElementsCustomModalVideo />
                                <!-- Preview Image -->
                                <img class="img-fluid" src="/assets/images/tablet-03.png" alt="content-image" />
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End section overlay -->
            </div>
            <!-- End content wrapper -->
        </div>
        <!-- End container -->
    </section>
</template>
