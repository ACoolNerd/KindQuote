<template>
    <section id="hero-26" class="bg--scroll hero-section">
        <div class="container">
            <div class="row d-flex align-items-center">
                <!-- HERO TEXT -->
                <div class="col-md-6">
                    <div class="hero-26-txt color--white wow fadeInRight">
                        <!-- Title -->
                        <h2 class="s-60 w-700">Add creativity to your project</h2>
                        <!-- Text -->
                        <p class="p-lg">Mauris donec turpis suscipit diam sapien ociis sagittis sapien tempor a volute ligula aliquet tortor egestas</p>
                        <!-- HERO QUICK FORM -->
                        <form name="quickform" class="quick-form form-shadow form-half mt-35">
                            <!-- Form Inputs -->
                            <div class="input-group">
                                <input type="email" name="email" class="form-control email r-06" placeholder="Your email address" autocomplete="off" required />
                                <span class="input-group-btn form-btn">
                                    <button type="submit" class="btn r-04 btn--theme hover--violet-500 submit">Get Started</button>
                                </span>
                            </div>
                            <!-- Form Message -->
                            <div class="quick-form-msg"><span class="loading"></span></div>
                        </form>
                        <!-- Advantages List -->
                        <ul class="advantages ico-15 clearfix">
                            <li><p class="p-sm">14 days free trial</p></li>
                            <li class="advantages-links-divider">
                                <p><span class="flaticon-minus"></span></p>
                            </li>
                            <li><p class="p-sm">No credit card needed</p></li>
                        </ul>
                    </div>
                </div>
                <!-- END HERO TEXT -->
                <!-- HERO IMAGE -->
                <div class="col-md-6">
                    <div class="hero-26-img wow fadeInLeft">
                        <img class="img-fluid" src="/assets/images/hero-26-img.png" alt="hero-image" />
                    </div>
                </div>
            </div>
            <!-- End row -->
        </div>
        <!-- End container -->
        <!-- WAVE SHAPE BOTTOM -->
        <div class="wave-shape-bottom">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 290"><path fill-opacity="1" d="M0,256L120,250.7C240,245,480,235,720,224C960,213,1200,203,1320,197.3L1440,192L1440,320L1320,320C1200,320,960,320,720,320C480,320,240,320,120,320L0,320Z"></path></svg>
        </div>
    </section>
</template>
