<template>
    <section class="pt-100 ws-wrapper content-section">
        <div class="container">
            <div class="bc-1-wrapper bg--02 bg--fixed r-16">
                <div class="section-overlay">
                    <div class="row d-flex align-items-center">
                        <!-- IMAGE BLOCK -->
                        <div class="col-md-6">
                            <div class="img-block left-column wow fadeInRight">
                                <img class="img-fluid" src="/assets/images/img-02.png" alt="content-image" />
                            </div>
                        </div>
                        <!-- TEXT BLOCK -->
                        <div class="col-md-6">
                            <div class="txt-block right-column wow fadeInLeft">
                                <!-- Section ID -->
                                <span class="section-id color--theme">Easy Integration</span>
                                <!-- Title -->
                                <h2 class="s-46 w-700">Integrate all your essential tools</h2>
                                <!-- Text -->
                                <p class="mb-0">Nemo ipsam egestas volute turpis egestas ipsum and purus sapien ultrice an aliquam quaerat ipsum augue turpis sapien cursus congue magna purus quaerat</p>
                                <!-- Button -->
                                <NuxtLink to="/integrations" class="btn btn-sm r-04 btn--tra-black hover--theme"> Explore all integrations </NuxtLink>
                            </div>
                        </div>
                        <!-- END TEXT BLOCK -->
                    </div>
                    <!-- End row -->
                </div>
                <!-- End section overlay -->
            </div>
            <!-- End content wrapper -->
        </div>
        <!-- End container -->
    </section>
</template>
