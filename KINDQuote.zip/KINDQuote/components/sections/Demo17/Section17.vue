<template>
    <section id="banner-13" class="pt-100 banner-section">
        <div class="container">
            <!-- BANNER-13 WRAPPER -->
            <div class="banner-13-wrapper bg--03 bg--scroll r-16 block-shadow">
                <div class="banner-overlay">
                    <div class="row d-flex align-items-center">
                        <!-- BANNER-13 TEXT -->
                        <div class="col-md-7">
                            <div class="banner-13-txt color--white">
                                <!-- Title -->
                                <h2 class="s-46 w-700">Getting started with Martex today!</h2>
                                <!-- Text -->
                                <p class="p-lg">Congue laoreet turpis neque auctor turpis vitae dolor a luctus placerat and magna ligula cursus</p>
                                <!-- Button -->
                                <a href="#hero-17" class="btn r-04 btn--theme hover--tra-white"> Get srarted - it's free </a>
                            </div>
                        </div>
                        <!-- END BANNER-13 TEXT -->
                        <!-- BANNER-13 IMAGE -->
                        <div class="col-md-5">
                            <div class="banner-13-img text-center">
                                <img class="img-fluid" src="/assets/images/img-04.png" alt="banner-image" />
                            </div>
                        </div>
                    </div>
                    <!-- End row -->
                </div>
                <!-- End banner overlay -->
            </div>
            <!-- END BANNER-13 WRAPPER -->
        </div>
        <!-- End container -->
    </section>
</template>
