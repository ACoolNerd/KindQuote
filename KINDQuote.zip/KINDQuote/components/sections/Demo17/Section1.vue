<template>
    <section id="hero-17" class="bg--fixed hero-section">
        <div class="container">
            <!-- HERO TEXT -->
            <div class="row justify-content-center">
                <div class="col-md-11 col-lg-10 col-xl-9">
                    <div class="hero-17-txt wow fadeInUp">
                        <!-- Title -->
                        <h2 class="s-60 w-700">Enhance your website design with Martex</h2>
                        <!-- Text -->
                        <p class="p-xl">Mauris donec ociis diam magnis sapien sagittis sapien tempor volute gravida aliquet tortor undo aliquet an egestas in magna egestas sapien quaerat</p>
                        <!-- HERO QUICK FORM -->
                        <form name="quickform" class="quick-form form-shadow mt-45">
                            <!-- Form Inputs -->
                            <div class="input-group">
                                <input type="email" name="email" class="form-control email r-06" placeholder="Your email address" autocomplete="off" required />
                                <span class="input-group-btn form-btn">
                                    <button type="submit" class="btn r-06 btn--theme hover--theme submit">Start free trial</button>
                                </span>
                            </div>
                            <!-- Form Message -->
                            <div class="quick-form-msg"><span class="loading"></span></div>
                        </form>
                    </div>
                </div>
                <!-- End row -->
            </div>
            <!-- END HERO TEXT -->
            <!-- BRANDS CAROUSEL -->
            <div id="brands-1">
                <div class="row">
                    <div class="col text-center">
                        <SlidersBrandLogos />
                    </div>
                </div>
                <!-- End row -->
            </div>
            <!-- END BRANDS CAROUSEL -->
        </div>
        <!-- End container -->
    </section>
</template>
