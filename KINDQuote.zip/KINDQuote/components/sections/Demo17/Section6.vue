<template>
    <section class="pt-100 ct-01 content-section division">
        <div class="container">
            <!-- SECTION CONTENT (ROW) -->
            <div class="row d-flex align-items-center">
                <!-- TEXT BLOCK -->
                <div class="col-md-6 order-last order-md-2">
                    <div class="txt-block left-column wow fadeInRight">
                        <!-- TEXT BOX -->
                        <div class="txt-box">
                            <!-- Title -->
                            <h5 class="s-24 w-700">Creative alternative solutions</h5>
                            <!-- Text -->
                            <p>Sodales tempor sapien quaerat ipsum undo congue laoreet turpis neque auctor turpis vitae dolor luctus placerat magna and ligula cursus purus vitae purus an ipsum suscipit</p>
                        </div>
                        <!-- END TEXT BOX -->
                        <!-- TEXT BOX -->
                        <div class="txt-box mb-0">
                            <!-- Title -->
                            <h5 class="s-24 w-700">Editing tools and exports</h5>
                            <!-- Text -->
                            <p>Tempor sapien sodales quaerat ipsum undo congue laoreet turpis neque auctor turpis vitae dolor luctus placerat magna and ligula cursus purus an ipsum vitae suscipit purus</p>
                            <!-- List -->
                            <ul class="simple-list">
                                <li class="list-item">
                                    <p>Tempor sapien quaerat an ipsum laoreet purus and sapien dolor an ultrice ipsum aliquam undo congue dolor cursus</p>
                                </li>
                                <li class="list-item">
                                    <p class="mb-0">Cursus purus suscipit vitae cubilia magnis volute egestas vitae sapien turpis ultrice auctor congue magna placerat</p>
                                </li>
                            </ul>
                        </div>
                        <!-- END TEXT BOX -->
                    </div>
                </div>
                <!-- END TEXT BLOCK -->
                <!-- IMAGE BLOCK -->
                <div class="col-md-6 order-first order-md-2">
                    <div class="img-block right-column wow fadeInLeft">
                        <img class="img-fluid" src="/assets/images/img-12.png" alt="content-image" />
                    </div>
                </div>
            </div>
            <!-- END SECTION CONTENT (ROW) -->
        </div>
        <!-- End container -->
    </section>
</template>
