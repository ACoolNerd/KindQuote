<template>
    <section id="banner-9" class="bg--02 py-70 x-border banner-section">
        <div class="container">
            <!-- BANNER-9 WRAPPER -->
            <div class="banner-7-wrapper">
                <div class="row justify-content-center d-flex align-items-center">
                    <!-- BANNER-9 TEXT -->
                    <div class="col-md-7 col-xl-5">
                        <div class="banner-9-txt">
                            <!-- Title -->
                            <h3 class="s-40 w-700">Still need help?</h3>
                            <!-- Text -->
                            <p class="p-lg">Don't hesitate to contact us about any question you might be interested in</p>
                            <!-- Button -->
                            <NuxtLink to="/contacts" class="btn r-04 btn--theme hover--theme">Ask your question here</NuxtLink>
                        </div>
                    </div>
                    <!-- BANNER-9 IMAGE -->
                    <div class="col-md-5 col-xl-5">
                        <div class="banner-9-img text-end">
                            <img class="img-fluid" src="/assets/images/help.png" alt="banner-image" />
                        </div>
                    </div>
                </div>
                <!-- End row -->
            </div>
            <!-- END BANNER-9 WRAPPER -->
        </div>
        <!-- End container -->
    </section>
</template>
