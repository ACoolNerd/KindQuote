<template>
    <section id="faqs-4" class="gr--whitesmoke inner-page-hero pb-100 faqs-section division">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-11 col-xl-10">
                    <div class="inner-page-title">
                        <h2 class="s-52 w-700">How Can We Help?</h2>
                    </div>
                    <ElementsTabs class="Tab-exp1">
                        <ElementsTab title="Getting Started" class="tab1-test">
                            <ElementsAccordionItem2 title="What is Martex and how does it work?">
                                <p>Sagittis congue augue egestas volutpat egestas magna suscipit egestas magna ipsum vitae purus congue efficitur and ipsum primis in cubilia laoreet augue egestas luctus donec and curabitur dapibus</p>
                            </ElementsAccordionItem2>
                            <ElementsAccordionItem2 title="What's inside the package?">
                                <p>Sagittis congue augue egestas volutpat egestas magna suscipit egestas tempor magna undo ipsum vitae purus and efficitur ipsum primis in cubilia laoreet tempor gravida luctus neque purus ipsum neque</p>
                                <p>Sapien egestas, congue gestas posuere cubilia congue ipsum mauris lectus laoreet and gestas neque vitae auctor dolor luctus placerat a magna cursus congue magna mpedit ligula undo congue. Maecenas agravida augue porttitor nunc, quis vehicula magna luctus tempor. Quisque vel laoreet turpis. Viverra augue, a augue tempor, dictum tempor diam. Sed pulvinar a consectetur nibh, imperdiet varius viverra</p>
                            </ElementsAccordionItem2>

                            <ElementsAccordionItem2 title="General settings">
                                <p>An augue cubilia laoreet magna suscipit egestas magna ipsum purus ipsum a primis an augue ultrice ligula egestas suscipit lectus gestas integer congue a lectus porta phasellus neque blandit tristique</p>
                                <p>Sagittis congue augue egestas volutpat egestas magna suscipit egestas and magna and vehicula</p>
                                <p>Sagittis congue augue egestas volutpat egestas magna suscipit lipsum egestas magna ipsum vitae a purus ipsum congue efficitur ipsum primis in cubilia laoreet augue egestas luctus donec and curabitur</p>
                            </ElementsAccordionItem2>

                            <ElementsAccordionItem2 title="Which languages does Martex support?">
                                <p>An augue cubilia laoreet and magna suscipit egestas magna ipsum purus ipsum primis undo augue ultrice ligula egestas suscipit lectus gestas integer congue a lectus porta tristique phasellus neque a blandit and tristique justo aliquam justo suscipit congue augue egestas volutpat egestas magna sem congue</p>
                                <p>An augue cubilia laoreet and magna suscipit egestas magna ipsum purus ipsum primis and augue efficitur ligula egestas suscipit lectus gestas integer congue a lectus porta phasellus neque</p>
                            </ElementsAccordionItem2>

                            <ElementsAccordionItem2 title="Automate testing with API">
                                <ul class="simple-list">
                                    <li class="list-item">
                                        <p>Curabitur ac dapibus libero quisque eu congue tristique egestas phasellus blandit tristique justo aliquam. Aliquam vitae molestie quisque sapien justo, aliquet aliquam molestie sed purus undo venenatis tempor gravida eget lacinia. Augue aliquam a suscipit tincidunt tincidunt massa</p>
                                    </li>
                                    <li class="list-item">
                                        <p>Aliquam vitae molestie nunc. Quisque sapien justo, aliquet non molestie sed purus, venenatis</p>
                                    </li>
                                    <li class="list-item">
                                        <p>Sagittis congue augue egestas volutpat egestas magna suscipit egestas magna ipsum vitae an efficitur purus undo ipsum primis in cubilia laoreet augue egestas luctus donec curabitur dapibus libero</p>
                                    </li>
                                </ul>
                            </ElementsAccordionItem2>
                        </ElementsTab>

                        <ElementsTab title="My Account">
                            <ul class="simple-list">
                                <li class="list-item">
                                    <p>Curabitur ac dapibus libero quisque eu congue tristique egestas phasellus blandit tristique justo aliquam. Aliquam vitae molestie quisque sapien justo, aliquet aliquam molestie sed purus undo venenatis tempor gravida eget lacinia. Augue aliquam a suscipit tincidunt tincidunt massa</p>
                                </li>
                                <li class="list-item">
                                    <p>Aliquam vitae molestie nunc. Quisque sapien justo, aliquet non molestie sed purus, venenatis</p>
                                </li>
                                <li class="list-item">
                                    <p>Sagittis congue augue egestas volutpat egestas magna suscipit egestas magna ipsum vitae an efficitur purus undo ipsum primis in cubilia laoreet augue egestas luctus donec curabitur dapibus libero</p>
                                </li>
                            </ul>
                        </ElementsTab>

                        <ElementsTab title="Pricing Plans">
                            <h5>How much does Martex cost?</h5>
                            <p>Sagittis congue augue egestas volutpat egestas magna suscipit egestas and magna ipsum vitae Sagittis congue augue egestas volutpat egestas and magna suscipit an egestas magna ipsum vitae purus congue efficitur ipsum primis in cubilia laoreet augue egestas luctus donec and curabitur dapibus</p>
                            <p>Sagittis congue augue egestas volutpat egestas magna suscipit egestas and magna ipsum vitae Sagittis congue augue egestas volutpat egestas and magna suscipit an egestas magna ipsum vitae purus congue efficitur ipsum primis in cubilia laoreet augue egestas luctus donec and curabitur dapibus</p>
                            <p>Sagittis congue augue egestas volutpat egestas magna suscipit egestas and magna ipsum vitae Sagittis congue augue egestas volutpat egestas and magna suscipit an egestas magna ipsum vitae purus congue efficitur ipsum primis in cubilia laoreet augue egestas luctus donec and curabitur dapibus</p>
                            <h5>I didn't receive the license key after purchased</h5>
                            <p>Sagittis congue augue egestas volutpat egestas magna suscipit egestas magna ipsum vitae purus congue efficitur ipsum primis in cubilia laoreet augue egestas luctus donec and curabitur dapibus</p>
                            <h5>Do you offer discounts for annual plans?</h5>
                            <p>Sagittis congue augue egestas volutpat egestas magna suscipit egestas magna ipsum vitae purus congue efficitur ipsum primis in cubilia laoreet augue egestas luctus donec and curabitur dapibus</p>
                        </ElementsTab>

                        <ElementsTab title="Other Questions">
                            <h5>How do I get the error log?</h5>
                            <p>Sagittis congue augue egestas volutpat egestas magna suscipit egestas and magna ipsum vitae Sagittis congue augue egestas volutpat egestas and magna suscipit an egestas magna ipsum vitae purus congue efficitur ipsum primis in cubilia laoreet augue egestas luctus donec and curabitur dapibus</p>
                            <h5>I forgot my folder password, what should I do?</h5>
                            <p>Sagittis congue augue egestas volutpat egestas magna suscipit egestas magna ipsum vitae purus congue efficitur ipsum primis in cubilia laoreet augue egestas luctus donec and curabitur dapibus</p>
                        </ElementsTab>
                    </ElementsTabs>
                </div>
            </div>
        </div>
    </section>
</template>
