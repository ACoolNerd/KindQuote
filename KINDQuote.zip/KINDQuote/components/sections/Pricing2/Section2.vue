<template>
    <section id="comp-table" class="pb-60 pricing-section division">
        <div class="container">
            <!-- SECTION TITLE -->
            <div class="row justify-content-center">
                <div class="col-md-10 col-lg-9">
                    <div class="section-title mb-70">
                        <!-- Title -->
                        <h2 class="s-52 w-700">Compare Our Plans</h2>
                        <!-- Text -->
                        <p class="p-xl">Complete list of features available in our pricing plans</p>
                    </div>
                </div>
            </div>
            <!-- PRICING COMPARE -->
            <div class="comp-table wow fadeInUp">
                <div class="row">
                    <div class="col">
                        <!-- Table -->
                        <div class="table-responsive mb-50">
                            <table class="table text-center">
                                <thead>
                                    <tr>
                                        <th style="width: 34%"></th>
                                        <th style="width: 22%">Starter</th>
                                        <th style="width: 22%">Basic</th>
                                        <th style="width: 22%">Premium</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th scope="row" class="text-start">Available Projects</th>
                                        <td class="color--black">Up to 2</td>
                                        <td class="color--black">Up to 250</td>
                                        <td class="color--black">Unlimited</td>
                                    </tr>
                                    <tr>
                                        <th scope="row" class="text-start">Available Storage</th>
                                        <td class="color--black">2Gb</td>
                                        <td class="color--black">50Gb</td>
                                        <td class="color--black">350Gb</td>
                                    </tr>
                                    <tr>
                                        <th scope="row" class="text-start">Private Cloud Hosting</th>
                                        <td class="ico-15 disabled-option"><span class="flaticon-cancel"></span></td>
                                        <td class="ico-15 disabled-option"><span class="flaticon-cancel"></span></td>
                                        <td class="ico-20 color--theme"><span class="flaticon-check"></span></td>
                                    </tr>
                                    <tr>
                                        <th scope="row" class="text-start">User Permissions</th>
                                        <td class="ico-20 color--theme"><span class="flaticon-check"></span></td>
                                        <td class="ico-20 color--theme"><span class="flaticon-check"></span></td>
                                        <td class="ico-20 color--theme"><span class="flaticon-check"></span></td>
                                    </tr>
                                    <tr>
                                        <th scope="row" class="text-start">Direct Integrations</th>
                                        <td class="ico-20 color--theme"><span class="flaticon-check"></span></td>
                                        <td class="ico-20 color--theme"><span class="flaticon-check"></span></td>
                                        <td class="ico-20 color--theme"><span class="flaticon-check"></span></td>
                                    </tr>
                                    <tr>
                                        <th scope="row" class="text-start">Reusable Components</th>
                                        <td class="ico-15 disabled-option"><span class="flaticon-cancel"></span></td>
                                        <td class="ico-20 color--theme"><span class="flaticon-check"></span></td>
                                        <td class="ico-20 color--theme"><span class="flaticon-check"></span></td>
                                    </tr>
                                    <tr>
                                        <th scope="row" class="text-start">Data Backup</th>
                                        <td class="color--black">Weekly</td>
                                        <td class="color--black">Daily</td>
                                        <td class="color--black">Daily</td>
                                    </tr>
                                    <tr>
                                        <th scope="row" class="text-start">No Ads. No Trackers</th>
                                        <td class="ico-15 disabled-option"><span class="flaticon-cancel"></span></td>
                                        <td class="ico-20 color--theme"><span class="flaticon-check"></span></td>
                                        <td class="ico-20 color--theme"><span class="flaticon-check"></span></td>
                                    </tr>
                                    <tr>
                                        <th scope="row" class="text-start">Advanced Security</th>
                                        <td class="ico-15 disabled-option"><span class="flaticon-cancel"></span></td>
                                        <td class="ico-20 color--theme"><span class="flaticon-check"></span></td>
                                        <td class="ico-20 color--theme"><span class="flaticon-check"></span></td>
                                    </tr>
                                    <tr>
                                        <th scope="row" class="text-start">Shared Team Workspace</th>
                                        <td class="ico-15 disabled-option"><span class="flaticon-cancel"></span></td>
                                        <td class="ico-20 color--theme"><span class="flaticon-check"></span></td>
                                        <td class="ico-20 color--theme"><span class="flaticon-check"></span></td>
                                    </tr>
                                    <tr>
                                        <th scope="row" class="text-start">Team Management</th>
                                        <td class="ico-15 disabled-option"><span class="flaticon-cancel"></span></td>
                                        <td class="ico-15 disabled-option"><span class="flaticon-cancel"></span></td>
                                        <td class="ico-20 color--theme"><span class="flaticon-check"></span></td>
                                    </tr>
                                    <tr class="table-last-tr">
                                        <th scope="row" class="text-start">Customer Support</th>
                                        <td class="color--black">Limited</td>
                                        <td class="color--black">Basic</td>
                                        <td class="color--black">Priority</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!-- End Table -->
                    </div>
                </div>
            </div>
            <!-- END PRICING COMPARE -->
            <!-- PRICING COMPARE PAYMENT -->
            <div class="comp-table-payment">
                <div class="row row-cols-1 row-cols-md-3">
                    <!-- Payment Methods -->
                    <div class="col col-lg-5">
                        <div id="pbox-1" class="pbox mb-40 wow fadeInUp">
                            <!-- Title -->
                            <h6 class="s-18 w-700">Accepted Payment Methods</h6>
                            <!-- Payment Icons -->
                            <ul class="payment-icons ico-45 mt-25">
                                <li><img src="/assets/images/png_icons/visa.png" alt="payment-icon" /></li>
                                <li><img src="/assets/images/png_icons/am.png" alt="payment-icon" /></li>
                                <li><img src="/assets/images/png_icons/discover.png" alt="payment-icon" /></li>
                                <li><img src="/assets/images/png_icons/paypal.png" alt="payment-icon" /></li>
                                <li><img src="/assets/images/png_icons/jcb.png" alt="payment-icon" /></li>
                                <li><img src="/assets/images/png_icons/shopify.png" alt="payment-icon" /></li>
                            </ul>
                        </div>
                    </div>
                    <!-- Payment Guarantee -->
                    <div class="col col-lg-4">
                        <div id="pbox-2" class="pbox mb-40 wow fadeInUp">
                            <!-- Title -->
                            <h6 class="s-18 w-700">Money Back Guarantee</h6>
                            <!-- Text -->
                            <p>Explore Martex Premium for 14 days. If it’s not a perfect fit, receive a full refund.</p>
                        </div>
                    </div>
                    <!-- Payment Encrypted -->
                    <div class="col col-lg-3">
                        <div id="pbox-3" class="pbox mb-40 wow fadeInUp">
                            <!-- Title -->
                            <h6 class="s-18 w-700">SSL Encrypted Payment</h6>
                            <!-- Text -->
                            <p>Your information is protected by 256-bit SSL encryption.</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END PRICING COMPARE PAYMENT -->
        </div>
        <!-- End container -->
    </section>
</template>
