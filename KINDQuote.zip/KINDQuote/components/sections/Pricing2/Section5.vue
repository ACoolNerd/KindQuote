<template>
    <section id="banner-1" class="pt-100 banner-section">
        <div class="container">
            <!-- BANNER-1 WRAPPER -->
            <div class="banner-1-wrapper r-16">
                <div class="banner-overlay bg--05 bg--scroll">
                    <div class="row">
                        <!-- BANNER-1 TEXT -->
                        <div class="col">
                            <div class="banner-1-txt color--white">
                                <!-- Title -->
                                <h2 class="s-45 w-700">Give it a try, it's free!</h2>
                                <!-- Text -->
                                <p class="p-xl">It only takes a few clicks to get started</p>
                                <!-- Button -->
                                <NuxtLink to="/signup-1" class="btn r-04 btn--theme hover--tra-white">Get srarted - it's free </NuxtLink>
                                <!-- Button Text -->
                                <p class="p-sm btn-txt ico-15 o-85"><span class="flaticon-check"></span> Free for 14 days, no credit card required.</p>
                            </div>
                        </div>
                        <!-- END BANNER-1 TEXT -->
                    </div>
                    <!-- End row -->
                </div>
                <!-- End banner overlay -->
            </div>
            <!-- END BANNER-1 WRAPPER -->
        </div>
        <!-- End container -->
    </section>
</template>
