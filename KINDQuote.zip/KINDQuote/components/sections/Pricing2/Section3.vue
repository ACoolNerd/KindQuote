<template>
    <div id="brands-1" class="bg--white-400 py-80 brands-section">
        <div class="container">
            <!-- BRANDS TITLE -->
            <div class="row justify-content-center">
                <div class="col-md-10 col-lg-9">
                    <div class="brands-title mb-50">
                        <h5 class="s-17">Trusted and used by over 3,400 companies</h5>
                    </div>
                </div>
            </div>
            <!-- BRANDS CAROUSEL -->
            <div class="row">
                <div class="col text-center">
                    <SlidersBrandLogos />
                </div>
            </div>
            <!-- END BRANDS CAROUSEL -->
        </div>
        <!-- End container -->
    </div>
</template>
