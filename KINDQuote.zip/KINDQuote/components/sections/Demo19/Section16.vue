<template>
    <section id="banner-7" class="banner-section">
        <div class="banner-overlay py-100">
            <div class="container">
                <!-- BANNER-7 WRAPPER -->
                <div class="banner-7-wrapper">
                    <div class="row justify-content-center">
                        <!-- BANNER-7 TEXT -->
                        <div class="col-md-8">
                            <div class="banner-7-txt text-center">
                                <!-- Section ID -->
                                <span class="section-id">Get Started Now</span>
                                <!-- Title -->
                                <h2 class="s-48 w-700">Grow your business with integrated marketing tools</h2>
                                <!-- Buttons -->
                                <div class="btns-group">
                                    <NuxtLink to="/signup-1" class="btn r-04 btn--theme hover--theme">Get srarted - it's free </NuxtLink>
                                    <NuxtLink to="/pricing-1" class="btn r-04 btn--tra-black hover--theme">Discover pricing</NuxtLink>
                                </div>
                                <!-- Button Text -->
                                <p class="btn-txt ico-15">Free for 14 days - no credit card required.</p>
                            </div>
                        </div>
                    </div>
                    <!-- End row -->
                </div>
                <!-- END BANNER-7 WRAPPER -->
            </div>
            <!-- End container -->
        </div>
        <!-- End banner overlay -->
    </section>
    <!-- END BANNER-7 -->
    <!-- DIVIDER LINE -->
    <hr class="divider" />
</template>
