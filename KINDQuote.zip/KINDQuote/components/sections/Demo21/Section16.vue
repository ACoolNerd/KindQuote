<template>
    <section id="reviews-1" class="pt-100 shape--06 shape--gr-whitesmoke reviews-section">
        <div class="container">
            <!-- SECTION TITLE -->
            <div class="row justify-content-center">
                <div class="col-md-10 col-lg-9">
                    <div class="section-title mb-70">
                        <!-- Title -->
                        <h2 class="s-50 w-700">Our Happy Customers</h2>
                        <!-- Text -->
                        <p class="s-21 color--grey">Ligula risus auctor tempus magna feugiat lacinia.</p>
                    </div>
                </div>
            </div>
            <!-- TESTIMONIALS CONTENT -->
            <div class="row">
                <div class="col">
                    <SlidersTetimonials />
                </div>
            </div>
            <!-- END TESTIMONIALS CONTENT -->
        </div>
        <!-- End container -->
    </section>
</template>
