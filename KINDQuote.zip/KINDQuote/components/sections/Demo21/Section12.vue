<template>
    <section id="features-5" class="bg--02 py-100 features-section division">
        <div class="container">
            <!-- SECTION TITLE -->
            <div class="row justify-content-center">
                <div class="col-md-10 col-lg-9">
                    <div class="section-title mb-70">
                        <!-- Title -->
                        <h2 class="s-50 w-700">Track the progress towards objectives with key results</h2>
                        <!-- Text -->
                        <p class="s-21 color--grey">Ligula risus auctor tempus magna feugiat lacinia.</p>
                    </div>
                </div>
            </div>
            <!-- FEATURES-5 WRAPPER -->
            <div class="fbox-wrapper text-center">
                <div class="row d-flex align-items-center">
                    <!-- FEATURE BOX #1 -->
                    <div class="col-md-6">
                        <div class="fbox-5 fb-1 bg--white-100 block-shadow r-16 wow fadeInUp">
                            <!-- Text -->
                            <div class="fbox-txt order-last order-md-2">
                                <h5 class="s-26 w-700">Marketing Integrations</h5>
                                <p>Aliquam a augue suscipit luctus diam neque purus ipsum neque and dolor primis libero</p>
                            </div>
                            <!-- Image -->
                            <div class="fbox-5-img order-first order-md-2">
                                <img class="img-fluid" src="/assets/images/f_06.png" alt="feature-image" />
                            </div>
                        </div>
                    </div>
                    <!-- END FEATURE BOX #1 -->
                    <!-- FEATURE BOX #2 -->
                    <div class="col-md-6">
                        <div class="fbox-5 fb-2 bg--white-100 block-shadow r-16 wow fadeInUp">
                            <!-- Image -->
                            <div class="fbox-5-img">
                                <img class="img-fluid" src="/assets/images/f_04.png" alt="feature-image" />
                            </div>
                            <!-- Text -->
                            <div class="fbox-txt">
                                <h5 class="s-26 w-700">Easy Automations</h5>
                                <p>Aliquam a augue suscipit luctus diam neque purus ipsum neque and dolor primis libero</p>
                            </div>
                        </div>
                    </div>
                    <!-- END FEATURE BOX #2 -->
                </div>
                <!-- End row -->
            </div>
            <!-- END FEATURES-5 WRAPPER -->
        </div>
        <!-- End container -->
    </section>
</template>
