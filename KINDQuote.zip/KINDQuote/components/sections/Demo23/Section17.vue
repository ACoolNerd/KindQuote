<template>
    <section id="banner-16" class="banner-section">
        <div class="container">
            <!-- BANNER-16 WRAPPER -->
            <div class="banner-16-wrapper bg--white-100 block-border r-16">
                <div class="banner-overlay bg--fixed">
                    <div class="row">
                        <!-- BANNER-1 TEXT -->
                        <div class="col">
                            <div class="banner-16-txt text-center">
                                <!-- Title -->
                                <h4 class="s-24 w-700">Choose a plan when you are ready</h4>
                                <!-- Text -->
                                <p class="p-md mb-0">Sodales tempor sapien quaerat ipsum undo congue laoreet turpis neque auctor turpis vitae dolor luctus placerat magna cursus</p>
                                <!-- Link -->
                                <div class="txt-block-tra-link mt-15">
                                    <NuxtLink to="/pricing-1" class="tra-link ico-20 color--theme"> Discover our pricing <span class="flaticon-next"></span> </NuxtLink>
                                </div>
                            </div>
                        </div>
                        <!-- END BANNER-16 TEXT -->
                    </div>
                    <!-- End row -->
                </div>
                <!-- End banner overlay -->
            </div>
            <!-- END BANNER-16 WRAPPER -->
        </div>
        <!-- End container -->
    </section>
</template>
