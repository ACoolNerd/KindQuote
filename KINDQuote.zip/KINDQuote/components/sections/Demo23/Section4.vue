<template>
    <section class="bg--white-400 py-100 ct-01 content-section division">
        <div class="container">
            <!-- SECTION CONTENT (ROW) -->
            <div class="row d-flex align-items-center">
                <!-- TEXT BLOCK -->
                <div class="col-md-6 order-last order-md-2">
                    <div class="txt-block left-column wow fadeInRight">
                        <!-- Section ID -->
                        <span class="section-id color--grey">One-Stop Solution</span>
                        <!-- Title -->
                        <h2 class="s-46 w-700">Smart solutions, real-time results</h2>
                        <!-- Text -->
                        <p>Sodales tempor sapien quaerat ipsum undo congue laoreet turpis neque auctor turpis vitae dolor luctus placerat magna and ligula cursus purus vitae purus an ipsum suscipit</p>
                        <!-- Text -->
                        <p class="mb-0">Nemo ipsam egestas volute turpis egestas ipsum and purus sapien ultrice an aliquam quaerat ipsum augue turpis sapien cursus congue magna purus quaerat at ligula purus egestas magna cursus undo varius purus magnis sapien quaerat</p>
                        <!-- Link -->
                        <div class="txt-block-tra-link mt-25">
                            <a href="#features-5" class="tra-link ico-20 color--theme"> Friendly with others <span class="flaticon-next"></span> </a>
                        </div>
                    </div>
                </div>
                <!-- END TEXT BLOCK -->
                <!-- IMAGE BLOCK -->
                <div class="col-md-6 order-first order-md-2">
                    <div class="img-block right-column wow fadeInLeft">
                        <img class="img-fluid" src="/assets/images/img-09.png" alt="content-image" />
                    </div>
                </div>
            </div>
            <!-- END SECTION CONTENT (ROW) -->
        </div>
        <!-- End container -->
    </section>
</template>
