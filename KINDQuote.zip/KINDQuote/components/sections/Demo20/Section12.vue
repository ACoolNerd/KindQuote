<template>
    <section class="pt-100 ct-02 content-section division">
        <div class="container">
            <!-- SECTION CONTENT (ROW) -->
            <div class="row d-flex align-items-center">
                <!-- IMAGE BLOCK -->
                <div class="col-md-6">
                    <div class="img-block left-column wow fadeInRight">
                        <img class="img-fluid" src="/assets/images/img-10.png" alt="content-image" />
                    </div>
                </div>
                <!-- TEXT BLOCK -->
                <div class="col-md-6">
                    <div class="txt-block right-column wow fadeInLeft">
                        <!-- Section ID -->
                        <span class="section-id color--black">Control Data Access</span>
                        <!-- Title -->
                        <h2 class="s-44 w-700">All your marketing data in one place</h2>
                        <!-- Text -->
                        <p>Sodales tempor sapien quaerat ipsum undo congue laoreet turpis neque auctor turpis vitae dolor luctus placerat magna and ligula cursus purus vitae purus an ipsum suscipit</p>
                        <!-- Small Title -->
                        <h5 class="s-24 w-700">The smarter way to work</h5>
                        <!-- CONTENT BOX #1 -->
                        <div class="cbox-1 ico-15">
                            <div class="ico-wrap color--theme">
                                <div class="cbox-1-ico"><span class="flaticon-check"></span></div>
                            </div>
                            <div class="cbox-1-txt">
                                <p>Magna dolor luctus at egestas sapien</p>
                            </div>
                        </div>
                        <!-- CONTENT BOX #2 -->
                        <div class="cbox-1 ico-15">
                            <div class="ico-wrap color--theme">
                                <div class="cbox-1-ico"><span class="flaticon-check"></span></div>
                            </div>
                            <div class="cbox-1-txt">
                                <p>Cursus purus suscipit vitae cubilia magnis volute egestas vitae sapien turpis ultrice auctor congue varius magnis</p>
                            </div>
                        </div>
                        <!-- CONTENT BOX #3 -->
                        <div class="cbox-1 ico-15">
                            <div class="ico-wrap color--theme">
                                <div class="cbox-1-ico"><span class="flaticon-check"></span></div>
                            </div>
                            <div class="cbox-1-txt">
                                <p class="mb-0">Volute turpis dolores and sagittis congue</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- END TEXT BLOCK -->
            </div>
            <!-- END SECTION CONTENT (ROW) -->
        </div>
        <!-- End container -->
    </section>
</template>
