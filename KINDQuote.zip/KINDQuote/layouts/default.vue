<template>
    <div id="page" class="page font--jakarta">
        <HeaderLayout1 />
        <slot />
        <FooterLayout1 />
    </div>
</template>

<style src="~/assets/css/color-scheme/default.scss" lang="scss"></style>
