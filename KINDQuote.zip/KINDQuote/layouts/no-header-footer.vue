<template>
  <div id="page" class="page font--jakarta">
      <slot />
  </div>
</template>

<style src="~/assets/css/color-scheme/default.scss" lang="scss"></style>